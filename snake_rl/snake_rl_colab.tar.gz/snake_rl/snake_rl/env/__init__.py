"""Snake 环境。

环境只负责游戏逻辑，不依赖 pygame；渲染在 :mod:`snake_rl.env.renderer` 中。
"""

from .board_observations import (
    BOARD_CHANNEL_NAMES,
    BOARD_CHANNELS,
    observe_board,
)
from .snake_env import (
    Action,
    Direction,
    Point,
    SnakeEnv,
    SnakeState,
    StepOutcome,
    relative_action,
)
from .vector_env import VectorSnakeEnv

__all__ = [
    "Action",
    "Direction",
    "Point",
    "SnakeEnv",
    "SnakeState",
    "StepOutcome",
    "relative_action",
    "BOARD_CHANNEL_NAMES",
    "BOARD_CHANNELS",
    "observe_board",
    "VectorSnakeEnv",
]
