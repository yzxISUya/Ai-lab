# teach/：边做边学

这个文件夹不是 API 文档，而是这个项目的**课程 + 实验记录**。代码告诉我们“怎么跑”，
这里回答“为什么这样设计、怎么判断有没有变好、下一步改什么”。

## 怎么用

1. 按顺序读 `00 → 01 → 02 → 03`。
2. 每份文档先看“目标”和“先想一个问题”，**不要急着看代码**。
3. 跑文档里的命令，把结果记到 `lab-log-template.md` 的副本里。
4. 做完自测题，再进入下一阶段。

每个阶段都遵循同一个节奏：

```
概念 → 预测 → 实现 → 跑实验 → 记录 → 自测 → 再改进
```

“预测”很重要：在跑之前先写下你认为会发生什么。预测错了，说明你对某个机制的理解
还有缺口，这比单纯看到一条曲线更有价值。

## 进度

| 阶段    | 主题                 | 状态      | 主文档                                                 |
| ------- | -------------------- | --------- | ------------------------------------------------------ |
| Stage 0 | 环境、渲染、随机基线 | ✅        | [03-stage0-environment.md](03-stage0-environment.md)   |
| Stage 1 | 复刻 DQN 基线        | ✅        | [04-stage1-dqn-baseline.md](04-stage1-dqn-baseline.md) |
| Stage 2 | 修 DQN + 消融        | ⬜ 下一步 | [05-stage2-dqn-fixes.md](05-stage2-dqn-fixes.md)       |
| Stage 3 | 观察与奖励工程       | ⬜        | 待写                                                   |
| Stage 4 | PPO 对比             | ⬜        | 待写                                                   |
| Stage 5 | 多智能体（可选）     | ⬜        | 待写                                                   |

Stage 1 最终 greedy eval（100 局，seed=20_000 起）：**mean 27.14 / median 26 / max 52 /
std 10.13**，95/100 死于 self collision。详见
[`logs/stage1-dqn-baseline.md`](logs/stage1-dqn-baseline.md)。

## 文档索引

| 文档                                                   | 内容                                            |
| ------------------------------------------------------ | ----------------------------------------------- |
| [00-roadmap.md](00-roadmap.md)                         | 完整路线、评估协议、每个阶段的完成标准          |
| [01-mdp-snake.md](01-mdp-snake.md)                     | 把 Snake 写成 MDP：状态、动作、奖励、折扣、终止 |
| [02-reference-reading.md](02-reference-reading.md)     | 参考项目逐文件阅读与“哪里可以改”                |
| [03-stage0-environment.md](03-stage0-environment.md)   | 本仓库 Stage 0 的代码走读与实验                 |
| [04-stage1-dqn-baseline.md](04-stage1-dqn-baseline.md) | Stage 1：11 维观察、QNet、replay、训练与评估    |
| [05-stage2-dqn-fixes.md](05-stage2-dqn-fixes.md)       | Stage 2：目标网络、Double、Huber、消融设计      |
| [lab-log-template.md](lab-log-template.md)             | 实验记录模板与指标定义                          |

## 和你的 RL 笔记的对应关系

你的笔记已经覆盖了理论主线，这里只做“落到代码”的补充：

| 笔记里的内容            | 在这个项目里对应什么                                 |
| ----------------------- | ---------------------------------------------------- |
| MDP 五要素              | `01-mdp-snake.md`；`SnakeEnv` 的 `state/step/reward` |
| 策略、回报、价值        | Stage 1 的 Q 网络与 TD target                        |
| Bellman 方程            | Stage 1 的 `y = r + γ max Q(s')`                     |
| DQN、经验回放、目标网络 | Stage 1 复刻；Stage 2 修正                           |
| 策略梯度、A2C、PPO      | Stage 4                                              |
| 多 agent、非平稳性      | Stage 5（可选）                                      |

## 实验纪律

这几条比任何超参数都重要：

1. **一次只改一个变量。** 同时改学习率、奖励和网络结构，曲线变好也不知道是谁的功劳。
2. **固定种子。** 训练种子、评估种子、动作随机种子都要固定；报告多种子的均值和方差。
3. **训练与评估分开。** 评估用 greedy 策略、固定 seed、无渲染，不能拿训练时的 epsilon 探索数据当成绩。
4. **记录配置。** 每次实验把 `EnvConfig`、模型结构、学习率、gamma、epsilon 调度、训练局数写进 lab log。
5. **不要只看最高分。** 最高分可能是运气；看均值、中位数、分布、截断率、死因。
6. **不要在评估种子上调参。** 可以先用一组 seed 做开发，最后用另一组 seed 报告。

## 常用命令

```powershell
# 测试
.\.venv\Scripts\python.exe -m pytest

# 人类试玩
.\.venv\Scripts\python.exe scripts\play_human.py

# 随机基线
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100

# 小棋盘 + 固定超时
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --width 10 --height 10 --timeout-factor 50
```

## 一个提醒

这个项目的目标不是把分数刷到多高，而是让你能回答：

- 这个算法在优化什么目标？
- 我改的这个东西，理论上应该影响什么？
- 实验数据支持这个解释吗？
- 如果换一个 seed / 换一个棋盘，结论还成立吗？

能稳定回答这四个问题，比一条漂亮的曲线更有价值。
