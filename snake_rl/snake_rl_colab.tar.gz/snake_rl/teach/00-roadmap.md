# 00 · 路线图

## 项目目标

用 Snake 这个足够小、足够直观的游戏，把下面这条链路走通：

```
MDP 建模 → 环境实现 → 基线策略 → DQN → 定位问题 → 消融实验 → 观察/奖励改进 → 策略梯度对比
```

参考项目 [patrickloeber/snake-ai-pytorch](https://github.com/patrickloeber/snake-ai-pytorch)
提供的是一个**可复刻的起点**，不是标准答案。它有几处刻意保留的“简化”，正好可以作为
Stage 2 的反面教材。

最终要得到的能力不是“会调 DQN 超参数”，而是：

1. 能把一个游戏说清楚：状态是什么、动作是什么、奖励是什么、什么时候结束。
2. 能写出可复现、可评估、无渲染依赖的训练循环。
3. 能用消融实验回答“这个改动有没有用”，而不是凭感觉。
4. 能解释 DQN/PPO 的关键设计为什么存在。

## 为什么选 Snake

适合：

- 动作离散且小（3 个相对动作）；
- 转移基本确定，调试时容易复现；
- episode 短，几分钟就能跑很多局；
- 奖励直观（吃食物/死亡），渲染一眼能看懂；
- 状态空间足够大，不能查表，必须用函数近似；
- 有很多自然的改进方向：观察、奖励、网络、探索、评估。

不适合：

- 它不是标准 benchmark，不要拿分数和论文比；
- 20×20 的棋盘、3 个动作，性能上限受实现细节影响很大；
- 奖励稀疏，早期学习曲线可能很难看；
- 参考项目的 11 维观察是**部分观察**，会限制上限。这本身是 Stage 3 的课题。

## 总路线

### Stage 0 · 环境与测量工具（已完成）

**目标**：先把“游戏”做对，再谈学习。

**概念**：MDP、状态 vs 观察、相对动作、奖励、termination/truncation、随机种子。

**交付物**：

- `snake_rl/env/snake_env.py`：纯逻辑环境；
- `snake_rl/env/renderer.py`：只在试玩/演示时用的渲染器；
- `scripts/play_human.py`、`scripts/random_agent.py`；
- `tests/test_snake_env.py`；15 个测试。

**完成标准**：

- 测试全过；
- 能解释为什么撞死后棋盘保持合法；
- 能解释为什么“走进当前尾巴”不算撞身体；
- 能解释超时为什么是 `truncated` 而不是 `terminated`；
- 随机基线可复现。

**实验**：20×20 与 10×10 的随机基线；不同 timeout factor。

---

### Stage 1 · 复刻 DQN 基线（已完成）

**目标**：先**忠实**复刻参考项目的核心算法，不急着修。把“它为什么能学”与
“它哪里不靠谱”分开。

**概念**：Q-learning、TD target、epsilon-greedy、经验回放、函数近似、自举（bootstrap）。

**交付物**：

```
snake_rl/env/observations.py     # 11 维特征
snake_rl/models/qnet.py          # 11 -> 256 -> 3 的 MLP
snake_rl/agents/dqn.py           # epsilon-greedy、replay、train_step
snake_rl/training/train_dqn.py   # 训练循环、CSV 日志、checkpoint
scripts/evaluate.py              # greedy 评估
```

实际实现与实验记录见 [04-stage1-dqn-baseline.md](04-stage1-dqn-baseline.md)
和 [logs/stage1-dqn-baseline.md](logs/stage1-dqn-baseline.md)。

**实际结果（seed=0）**：500 局，189,708 步，CPU 约 15.4 分钟。最终 greedy eval
100 局：mean **27.14**、median 26、max 52、std 10.13，self 95 / wall 5。
训练曲线上 mean100 在约 175 局后平台化在 25–30；主要失败模式是 self collision。

**要复刻的参考行为**：

- 11 维观察：3 个危险位 + 4 个方向 one-hot + 4 个食物相对方位；
- 2 层 MLP（11→256→3），ReLU；
- 经验回放，容量 100k；
- 每步 `train_short_memory`（单样本）；
- 每局 `train_long_memory`（batch=1000）；
- 在线网络同时算 target（**先不加目标网络**）；
- epsilon 随局数线性衰减到 0；
- 奖励：吃食物 +10，死亡 -10，其他 0。

**刻意不修**：目标网络、Double DQN、Huber、终止/截断区分。Stage 2 再逐个改。

**完成标准**：

- 无渲染训练能跑完 500+ 局；
- 评估均分明显高于随机基线；
- 能说清每个张量的形状，以及 target 是怎么算的；
- 能解释 `done` 为什么会让 target 退化成 `r`；
- 至少跑 1 个训练种子并记录曲线（seed=0 已完成；seed=1/2 留到 Stage 2 做方差对比）。

**实验**：

- 训练曲线（score、mean100、loss、epsilon）；
- greedy 评估 100 局；
- 与随机基线对比；
- 观察失败模式：绕圈、贴墙、追尾巴、过早死亡。

---

### Stage 2 · 修 DQN：从“能学”到“学得稳”

**目标**：一次只改一个东西，做消融。每个改动都要有“理论上它应该改善什么”的假设。

**概念**：目标网络、Double DQN、Huber loss、replay ratio、epsilon 调度、梯度裁剪、
终止/截断的正确 bootstrap。

详细步骤、代码改动位置和消融表见 [05-stage2-dqn-fixes.md](05-stage2-dqn-fixes.md)。

**建议的消融顺序**：

| 版本 | 改动                            | 预期影响                   |
| ---- | ------------------------------- | -------------------------- |
| A    | Stage 1 基线                    | 对照组                     |
| B    | + 目标网络（每 C 步同步）       | 降低“追自己尾巴”，训练更稳 |
| C    | + Double DQN                    | 降低 max 造成的 Q 值高估   |
| D    | + Huber + 梯度裁剪              | 对大 TD error 更鲁棒       |
| E    | + epsilon 调度（有下限/余弦）   | 后期保留探索，减少过早收敛 |
| F    | + 正确区分 terminated/truncated | 超时不再被当成死亡         |

**完成标准**：

- 每个版本至少 2–3 个种子；
- 一张消融表：最终评估均分/中位数/最高分/方差；
- 一条结论：哪个改动贡献最大，为什么；
- 能解释 Q 值高估、目标网络、Double DQN 的区别。

**注意**：

- 目标网络的同步频率 C 是超参数；
- Double DQN 是“用在线网络选动作，用目标网络评估”；
- 超时是截断，target 仍应 bootstrap；死亡才是终止；
- 评估时用 greedy，不探索。

---

### Stage 3 · 观察与奖励工程

**目标**：改“智能体看到什么”和“它为什么拿奖励”，而不只是改优化器。

**概念**：POMDP、特征工程、射线/距离特征、网格观察 + CNN、奖励塑形、
potential-based shaping、action masking。

**候选实验**：

1. **加距离特征**：食物相对位置、归一化的 dx/dy、曼哈顿距离。
2. **射线特征**：8 个方向到墙/身体的距离。
3. **网格观察 + CNN**：把棋盘编码成多通道网格（蛇身、头、食物），用小 CNN。
4. **奖励塑形**：用势函数
   $$F(s,s') = \gamma \Phi(s') - \Phi(s)$$
   例如 $\Phi(s) = -d_{\text{BFS}}(s,\text{food})$。
5. **Action masking**：把立即致死的动作 mask 掉，看它是否真的更好。
6. **超时/胜利处理**：不同 timeout 奖励、胜利奖励。

**完成标准**：

- 至少一个观察或奖励变体在固定评估协议下超过 Stage 2 的最好版本；
- 能解释为什么 11 维观察是部分观察，给出一个“同样 11 位、最优动作不同”的例子；
- 能识别奖励塑形带来的 reward hacking；
- 记录计算成本（每步耗时、显存/内存）。

**注意**：

- 观察变了，网络输入维度也变；不要同时改网络容量和观察；
- 归一化特征，避免大数值主导梯度；
- 网格 CNN 在 CPU 上可能很慢，先小棋盘验证；
- 奖励塑形不是免费的：它改变最优策略，除非是 potential-based。

---

### Stage 4 · PPO 对比

**目标**：从 off-policy 的 DQN 切到 on-policy 的 PPO，比较样本效率、稳定性、
实现复杂度。

**概念**：策略梯度、优势函数、GAE、PPO-Clip、熵正则、并行环境、on-policy 数据。

**计划交付物**：

- `snake_rl/agents/ppo.py`：Actor-Critic、GAE、clip loss；
- `snake_rl/training/train_ppo.py`：rollout → advantage → update；
- 向量化环境（至少 8 个并行 env）；
- 与 DQN 共用的评估脚本。

**完成标准**：

- PPO 能稳定学习，评估均分超过随机基线；
- 能解释 PPO 为什么需要旧策略的 log-prob；
- 能解释 GAE 的 $\lambda$ 在偏差/方差之间怎么权衡；
- 与 DQN 的对比表：样本效率、墙钟时间、稳定性、调参难度。

**注意**：

- PPO 是 on-policy：采集的数据更新几次后要丢掉；
- 优势归一化、观测归一化对稳定性影响很大；
- 截断 episode 的 GAE 处理与 DQN 的 bootstrap 类似，容易写错；
- 不要直接上大型 CNN，先用 MLP + 特征观察把流程跑通。

---

### Stage 5 · 多智能体/自对弈（可选）

**目标**：理解非平稳环境。两个蛇互相竞争时，对手策略在变，MDP 的“转移”不再固定。

**概念**：非平稳性、中心化训练/去中心化执行、自对弈、联赛、对手采样。

**可能的方向**：

- 双蛇抢食物；
- 一条蛇追、一条蛇逃；
- 自对弈 + 对手池（league）；
- 课程学习：先单蛇，再多蛇。

**完成标准**：

- 能解释为什么普通 Q-learning 的收敛保证在这里不成立；
- 能设计一个简单的评估：对固定对手、对历史对手、对当前对手。

这个阶段不是必须的。先把 Stage 1–3 做扎实。

---

## 每个阶段的完成定义（Definition of Done）

一个阶段算完成，需要同时满足：

1. 代码能从头跑通，有可复现命令；
2. 测试或 smoke test 通过；
3. 至少一组固定种子的评估结果；
4. 实验记录写进 `teach/`（配置、命令、指标、观察）；
5. 能用一段话回答“这个阶段最大的意外是什么”。

## 评估协议

从 Stage 1 开始固定使用，避免“这次分数高是因为 seed 好”。

**训练**：

- 训练种子：0、1、2（先跑 0，稳定后再加）；
- 每个种子保存配置、曲线、checkpoint。

**评估**：

- greedy 策略（epsilon=0），不渲染；
- 100 局，评估种子固定为 `10_000 + i`；
- 报告：
  - 分数：mean、median、max、std；
  - 步数：mean、median；
  - 食物效率：`score / steps`；
  - 死因分布：wall / self / timeout / win；
  - 截断率。
- 训练曲线用移动平均（例如最近 100 局）平滑后再看趋势。

**对比**：

- 同一张表里放多个版本；
- 不要只放最好的一次 run；
- 不要用评估种子调参；调参用另一组种子，最后再报告。

**记录**：

- 每次实验复制一份 `lab-log-template.md`；
- 写清楚“假设 → 改动 → 结果 → 解释 → 下一步”；
- 如果结果和假设相反，不要删掉，这通常是最有价值的一条。

## 参考项目的定位

先读 [02-reference-reading.md](02-reference-reading.md)。一句话总结：

> 它是一个很好的“最小可运行 DQN 教学实现”，但不是可靠的实验基线。
> 我们先复刻它，再逐项修；每一步都测量，不靠信仰。

## 推荐的外部资料

- Sutton & Barto, _Reinforcement Learning: An Introduction_（第 3、6、9、13 章）
- Mnih et al., 2015, _Human-level control through deep reinforcement learning_（DQN Nature）
- van Hasselt et al., 2016, _Deep Reinforcement Learning with Double Q-learning_
- Schulman et al., 2017, _Proximal Policy Optimization Algorithms_
- Ng et al., 1999, _Policy Invariance Under Reward Transformations_（potential-based shaping）
- 你自己的 RL 笔记：`D:\myBlog\content\posts\RF\index.md`
