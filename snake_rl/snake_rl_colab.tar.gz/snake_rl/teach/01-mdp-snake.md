# 01 · 把 Snake 写成 MDP

这份文档只做一件事：把“贪吃蛇”翻译成强化学习能处理的形式，并指出几个
**看起来是工程细节、实际上会改变算法正确性**的地方。

---

## 1. 五元组

MDP 是 $(S, A, P, R, \gamma)$。对应到 Snake：

| 要素                 | Snake 里是什么                     | 本项目的代码       |
| -------------------- | ---------------------------------- | ------------------ |
| 状态 $S$             | 蛇头、蛇身、食物、当前朝向、分数等 | `SnakeState`       |
| 动作 $A$             | 直行 / 右转 / 左转                 | `Action`           |
| 转移 $P(s'\mid s,a)$ | 移动、吃食物、死亡、刷新食物       | `SnakeEnv.step`    |
| 奖励 $R$             | 吃食物 +10，死亡 -10，其他 0       | `EnvConfig`        |
| 折扣 $\gamma$        | 未来奖励的权重                     | Stage 1 的 `gamma` |

底层状态可以写成：

$$
s = (\text{snake}, \text{food}, \text{direction}, \text{score}, \dots)
$$

其中 `snake` 是一个有序格子序列，第 0 个是头，最后一个是尾。这个状态是**完全可观测**的：
给定它和动作，下一步是确定的（除了食物刷新位置）。

> 注意：环境的状态 $S$ 和智能体实际看到的观察 $O$ 不是一回事。后面会反复用到这个区分。

---

## 2. 状态 vs 观察：11 维特征不是 Markov 状态

参考项目（以及我们 Stage 1 要复刻的版本）并不把完整棋盘喂给网络，而是手工压成 11 个 bit：

| 位置 | 含义                            |
| ---- | ------------------------------- |
| 0    | 正前方是否危险                  |
| 1    | 右方是否危险                    |
| 2    | 左方是否危险                    |
| 3–6  | 当前朝向 one-hot（左/右/上/下） |
| 7    | 食物在头的左边                  |
| 8    | 食物在头的右边                  |
| 9    | 食物在头的上边                  |
| 10   | 食物在头的下边                  |

“危险”指撞墙或撞身体。这个表示有几个明显的信息损失：

- **没有距离**：食物在右边 1 格还是 20 格，编码一样；
- **没有身体形状**：蛇身有多长、怎么绕，完全看不到；
- **只看相邻三格**：更远的危险（比如前方两格后是死胡同）看不到；
- **食物只有相对方位**：没有“多远”“中间有没有身体挡路”。

所以，11 维观察对应的其实是一个 **POMDP**（部分可观测马尔可夫决策过程），
而不是原 MDP。策略只能基于这个不完整的信息做决定。

### 一个“同一观察、不同最优动作”的例子

棋盘 10×10，蛇头在 $(8,5)$，朝右，食物都在头的右上方：

- 状态 A：食物在 $(9,4)$，蛇身很短，下方是开阔空间；
- 状态 B：食物在 $(9,1)$，蛇身很长、盘在下方（但不占相邻三格）。

两者的 11 位观察可以完全相同（三个危险位都是 0，朝向都是右，食物都在“右上”），
但最优动作可能不同：A 可以先直行再左转，或者绕一下；B 如果先向下绕，可能把身体
挤进更小的空间，所以它可能需要更早向上。网络没有足够信息区分它们，只能学一个折中策略。

这不是“网络不够大”，而是**观察本身丢了信息**。Stage 3 的观察工程就是从这里开始。

### 练习

> 自己构造两个 11 位观察完全相同、但最优动作不同的局面。写下来，Stage 3 时回头验证。

---

## 3. 动作：为什么用相对动作

我们的动作是相对于蛇当前朝向的：

| 当前朝向 | `STRAIGHT` | `RIGHT` | `LEFT` |
| -------- | ---------- | ------- | ------ |
| RIGHT    | RIGHT      | DOWN    | UP     |
| DOWN     | DOWN       | LEFT    | RIGHT  |
| LEFT     | LEFT       | UP      | DOWN   |
| UP       | UP         | RIGHT   | LEFT   |

这样做的好处：

1. **不可能一步掉头**。相对动作里没有“反向”这个选项。
2. **旋转等变性**。把整个棋盘旋转 90°，同一个相对动作仍然合理；网络不需要分别学四个方向。
3. **动作空间更小**。3 个而不是 4 个。

如果用绝对动作（上/下/左/右），就必须额外处理“当前朝右时选择左”这种非法动作：
要么 mask 掉，要么让环境拒绝，要么让智能体学会不要选。相对动作从根上避免了这个问题。

代价是：网络需要知道当前朝向，才能把“食物在右边”翻译成该左转还是右转。所以 11 维观察里
有 4 个方向 bit。

---

## 4. 奖励：稀疏、尺度、塑形

### 4.1 基线奖励

参考项目：

| 事件          |          奖励 |
| ------------- | ------------: |
| 吃到食物      |           +10 |
| 撞墙 / 撞自己 |           -10 |
| 其他每一步    |             0 |
| 超时          | -10，并且结束 |

这是典型的**稀疏奖励**：一局可能几十步都没有非零奖励。智能体死亡时，它需要把 -10
“归因”到前面很多步里的某一步，这就是 credit assignment 问题。

DQN 用 Bellman 自举来传播：吃到食物前一步的状态，其 Q 值会慢慢变大；再前一步又会
通过 bootstrap 变大。这就是为什么即使奖励稀疏，TD 方法也能学。

### 4.2 奖励尺度与 gamma

如果每步都能吃到食物，折扣回报的上界大约是：

$$
R_{\max} \cdot \frac{1}{1-\gamma}
$$

- $\gamma=0.9$：上界约 $10 \times 10 = 100$；
- $\gamma=0.99$：上界约 $10 \times 100 = 1000$。

Q 值越大，MSE 的梯度和 target 的尺度也越大。这就是后面要用 Huber loss、奖励缩放、
梯度裁剪的原因之一。

### 4.3 步惩罚的陷阱

一个很自然的想法：每步给 -0.01，让蛇尽快找食物。但要小心：

- 如果一局能活 1000 步，累计惩罚是 -10，和死亡一样；
- 如果 agent 发现“慢慢绕圈”比“冒险吃食物”更安全，它可能选择绕圈；
- 如果 timeout 惩罚不够，绕圈甚至没有代价。

所以步惩罚、死亡惩罚、timeout 惩罚要一起设计，不能单独调。

### 4.4 Potential-based reward shaping

如果你想奖励“离食物更近”，不要直接写：

$$
r' = r + \alpha \cdot \mathbb{1}[\text{更近}]
$$

更好的做法是选一个势函数 $\Phi(s)$，然后加：

$$
F(s,s') = \gamma \Phi(s') - \Phi(s)
$$

例如令 $\Phi(s) = -d_{\text{BFS}}(s, \text{food})$，即负的 BFS 距离。这样做的性质是：
对任意轨迹，塑形后的回报只比原回报多了一个只依赖起点和终点的项：

$$
\sum_{t=0}^{T-1} \gamma^t F(s_t,s_{t+1})
= \gamma^T \Phi(s_T) - \Phi(s_0)
$$

所以它不改变最优策略（Ng et al., 1999）。这就是“policy invariance”。

注意：

- 用 **BFS 距离**而不是曼哈顿距离，因为曼哈顿距离会穿墙、穿身体；
- 朴素的“更近 +1、更远 -1”并不是严格的 potential-based（少了 $\gamma$ 因子），
  可能被 reward hacking；
- 塑形只是加速学习，不是免费的午餐：它改变的是学习信号，不是最优策略。

### 4.5 超时奖励

我们的默认配置：

```python
timeout_reward = 0.0
```

并且把超时标记为 `truncated=True`，不是 `terminated=True`。原因见下一节。

---

## 5. 折扣因子：gamma 买的是“视野”

$$
G_t = R_{t+1} + \gamma R_{t+2} + \gamma^2 R_{t+3} + \cdots
$$

$\gamma$ 越接近 1，智能体越关心远期奖励。一个粗略的“有效视野”是：

$$
\frac{1}{1-\gamma}
$$

| gamma | 有效视野（步） |             10 步后的权重 |             20 步后的权重 |
| ----: | -------------: | ------------------------: | ------------------------: |
|  0.90 |            ~10 |  $0.9^{10} \approx 0.349$ |  $0.9^{20} \approx 0.122$ |
|  0.95 |            ~20 | $0.95^{10} \approx 0.599$ | $0.95^{20} \approx 0.358$ |
|  0.99 |           ~100 | $0.99^{10} \approx 0.904$ | $0.99^{20} \approx 0.818$ |

参考项目用 0.9。对 20×20 的棋盘，食物可能在 20–40 步外，0.9 的视野偏短。
但 gamma 变大也会让 Q 值变大、方差变大、学习更慢。Stage 1/2 可以做一个
`gamma ∈ {0.9, 0.95, 0.99}` 的消融。

> 先预测：你觉得哪个 gamma 在 10×10 上更好？20×20 呢？为什么？

---

## 6. 终止 vs 截断：一个很容易写错的地方

### 6.1 定义

- **terminated（终止）**：任务真的结束了。撞墙、撞自己、胜利。之后没有未来。
- **truncated（截断）**：因为外部时间限制而中断。状态本身不是终止状态，理论上还可以继续。

我们的环境把两者分开返回：

```python
state, reward, terminated, truncated, info = env.step(action)
```

### 6.2 对 DQN target 的影响

Bellman 最优目标：

$$
y = r + \gamma \max_{a'} Q_{\theta^-}(s',a')
$$

- 如果 $s'$ 是 terminated，未来价值为 0，所以

$$
y = r
$$

- 如果 $s'$ 是 truncated，未来仍然存在，应该继续 bootstrap：

$$
y = r + \gamma \max_{a'} Q_{\theta^-}(s',a')
$$

这就是为什么经验回放里最好存 `terminated`，而不是 `done = terminated or truncated`。
如果只存一个 `done`，你会在超时的时候错误地把未来价值砍掉。

### 6.3 参考项目的问题

参考项目只有一个 `game_over`：

```python
if self.is_collision() or self.frame_iteration > 100*len(self.snake):
    game_over = True
    reward = -10
```

超时和死亡被当成同一件事，target 都变成 `r`。这会让智能体低估“接近超时但仍然有希望”
的状态，也可能让它学会“快点结束”。更微妙的是，`frame_iteration` 是整局总步数，
吃食物不会重置它；所以一条活得很久、刚吃过食物的蛇，可能突然被截断。

我们的环境：

- `frame_iteration` → `steps_since_food`，吃食物时重置；
- 超时 → `truncated=True`，奖励默认 0；
- 死亡 → `terminated=True`，奖励 -10。

### 6.4 训练循环里的正确写法

```python
next_state, reward, terminated, truncated, info = env.step(action)
buffer.add(state, action, reward, next_state, terminated)  # 只存 terminated

# 计算 target
if terminated:
    target = reward
else:
    target = reward + gamma * max_q_target(next_state)
```

`truncated` 只用来决定“这一局要不要停”，不要用来砍掉 bootstrap。

---

## 7. 从 MDP 到训练循环

Stage 1 的循环大致是：

```python
state = env.reset()
while not env.done:
    action = epsilon_greedy(q_net, state, epsilon)
    next_state, reward, terminated, truncated, info = env.step(action)

    buffer.add(state, action, reward, next_state, terminated)
    if len(buffer) >= batch_size:
        update_q_network()

    state = next_state
```

注意几个容易混的东西：

| 概念       | 在代码里是什么                                |
| ---------- | --------------------------------------------- |
| 环境状态   | `SnakeState`（蛇、食物、朝向……）              |
| 智能体观察 | `observation(state)`（Stage 1 是 11 维向量）  |
| 动作       | 整数 0/1/2                                    |
| 经验       | `(obs, action, reward, next_obs, terminated)` |
| 目标       | `r` 或 `r + γ max Q_target(next_obs)`         |
| 探索       | epsilon-greedy                                |
| 评估       | epsilon=0，固定 seed，无渲染                  |

---

## 8. 设计检查清单

以后每换一个游戏，都可以拿这张表过一遍：

- [ ] 观察是否包含做决策所需的信息？是否 Markov？是否归一化？
- [ ] 动作空间是离散还是连续？有没有非法动作？要不要 mask？
- [ ] 奖励是否稀疏？尺度是否合理？有没有 reward hacking 的空间？
- [ ] 什么算 terminated？什么算 truncated？target 怎么处理？
- [ ] 随机性来自哪里？环境、动作、网络初始化、replay 采样是否都固定了种子？
- [ ] 训练时是否 headless？渲染是否只在评估/演示时开启？
- [ ] 评估协议是否独立于训练？是否报告分布而不是单个最高分？
- [ ] 有没有时间上限？超时会不会导致无限循环？

---

## 9. 自测题

先自己写答案，再展开对照。

<details>
<summary>1. 20×20 棋盘、初始蛇长 3，理论最高分是多少？</summary>

蛇最多占满 400 格。初始 3 格，每吃一个食物增长 1 格，所以最多吃
$400-3=397$ 个食物，最高分 397。前提是食物不会刷在蛇身上，且棋盘填满时判定胜利。
</details>

<details>
<summary>2. 为什么 11 维观察不是 Markov 状态？举一个例子。</summary>

它只编码相邻三格的危险、朝向和食物的相对方位，不编码距离、身体形状和更远的障碍。
例如食物都在“右上”，但一个在 1 格外、一个在 10 格外；或者蛇身一个很短、一个盘在下方。
这些局面的 11 位可能完全相同，但最优动作不同。基于它的策略是部分可观测策略。
</details>

<details>
<summary>3. 超时应该算 terminated 还是 truncated？target 怎么写？</summary>

算 truncated。状态本身不是终止状态，只是被时间限制打断。target 仍然要
$r + \gamma \max Q(s')$。只有撞墙/撞自己/胜利才是 terminated，target 才是 $r$。
</details>

<details>
<summary>4. 为什么“每步 -0.01”可能导致 agent 自杀？</summary>

如果死亡惩罚是 -10，而一局能活 1000 步，累计步惩罚也是 -10。继续活着不再有惩罚优势，
agent 可能选择尽早结束以避免未来风险。步惩罚、死亡惩罚、timeout 惩罚要一起调。
</details>

<details>
<summary>5. 为什么“走进当前尾巴”不算撞身体？</summary>

因为这一步不吃食物时，尾巴会同时腾出来。新头进入的是尾巴**即将离开**的格子，
移动后蛇身仍然不重叠。我们的碰撞检查在非进食时用 `snake[:-1]`，排除了尾巴。
如果这一步吃到食物，尾巴不腾，才需要检查整条蛇。
</details>

<details>
<summary>6. 为什么撞死后不让蛇头停在越界/重叠的位置？</summary>

保持状态合法：所有蛇身格子仍在棋盘内且不重复。这样渲染不会越界，测试也容易断言。
DQN 在 terminated 时不会使用 `next_state` 做 bootstrap，所以最终画面是否显示“撞进去”
不影响学习。
</details>

<details>
<summary>7. 参考项目的 `frame_iteration > 100*len(snake)` 有什么问题？</summary>

`frame_iteration` 是整局总步数，吃食物不会重置。一条活得很久、刚吃过食物的蛇也可能
马上被截断。更合理的是“距上次吃食物的步数”，我们用它作为 `steps_since_food`。
另外参考项目把超时当成死亡，target 不 bootstrap，这是另一个偏差。
</details>

<details>
<summary>8. gamma=0.9、食物在 20 步外，折扣权重是多少？这意味着什么？</summary>

$0.9^{20} \approx 0.1216$。单步奖励被衰减到约 12%，但 Q 学习会通过多步 bootstrap
逐步传播价值，所以不等于“完全学不到”。不过视野确实偏短，可能需要更多更新或更大的 gamma。
</details>

---

## 10. 本阶段动手

```powershell
# 1. 跑测试，确认环境行为符合上面的描述
.\.venv\Scripts\python.exe -m pytest

# 2. 随机基线：20x20
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100

# 3. 随机基线：10x10
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --width 10 --height 10

# 4. 改 timeout，观察截断率
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --timeout-factor 10
```

把结果记到 `lab-log-template.md` 的副本里。重点不是数字，而是回答：

- 为什么 20×20 的平均步数更长，但平均分没有明显更高？
- 随机 agent 的主要死因是什么？为什么几乎没有 self？
- timeout factor 变小，分数和截断率怎么变？

下一份：[02-reference-reading.md](02-reference-reading.md)。
