# 03 · Stage 0：环境、渲染与随机基线

这一阶段还没有 RL。目标只有一个：**把“游戏”做对，并且让后面每一步都可测量。**

代码已经写好并跑通：

- 15 个环境测试全部通过；
- 随机基线在 20×20 / 10×10 上都有可复现结果；
- 渲染器用 SDL dummy 驱动截帧检查过，HUD 不重叠；
- 训练路径完全不依赖 pygame。

---

## 1. 文件结构

```
snake_rl/
├── snake_rl/
│   ├── config.py              # EnvConfig
│   └── env/
│       ├── __init__.py        # 导出 Action/Direction/Point/SnakeEnv/...
│       ├── snake_env.py       # 纯逻辑环境
│       └── renderer.py        # Pygame 渲染
├── scripts/
│   ├── play_human.py          # 人类试玩
│   └── random_agent.py        # 随机策略基线
├── tests/
│   └── test_snake_env.py      # 15 个测试
├── runs/                      # 临时截图/日志（gitignore）
└── teach/
```

环境层不 import pygame。只有 `renderer.py` 和 `play_human.py` 会 import 它。
这意味着训练时没有窗口、没有帧率上限、没有事件循环。

---

## 2. 环境 API

```python
from snake_rl.config import EnvConfig
from snake_rl.env import Action, SnakeEnv

env = SnakeEnv(EnvConfig(width=10, height=10), seed=0)
state = env.state

while not env.done:
    action = Action.STRAIGHT
    state, reward, terminated, truncated, info = env.step(action)
```

### 2.1 `SnakeState`

```python
@dataclass(frozen=True)
class SnakeState:
    head: Point
    snake: tuple[Point, ...]
    food: Point | None
    direction: Direction
    score: int
    steps: int
    steps_since_food: int
```

- `snake[0]` 是头，最后一个是尾；
- `food is None` 只在棋盘被填满（胜利）时出现；
- `steps` 是本局总步数，`steps_since_food` 是距上次吃食物的步数；
- frozen dataclass：状态不可变，便于测试和回放。

### 2.2 `StepOutcome`

```python
class StepOutcome(NamedTuple):
    state: SnakeState
    reward: float
    terminated: bool
    truncated: bool
    info: dict
```

字段顺序模仿 Gymnasium，可以直接解包：

```python
next_state, reward, terminated, truncated, info = env.step(action)
```

### 2.3 动作

```python
class Action(IntEnum):
    STRAIGHT = 0
    RIGHT = 1
    LEFT = 2
```

用整数而不是 one-hot：

- 少一层 `np.array_equal`；
- DQN 的 `argmax` 直接输出整数；
- 打印/日志更短。

参考项目用 one-hot，语义完全一样。

---

## 3. 一次 `step` 的完整流程

以 10×10、初始头 (5,5)、朝右为例。

### 3.1 转向

```python
new_direction = self._turn(self.direction, action)
new_head = self._next_head(self.head, new_direction)
```

`Action.RIGHT` 在朝右时变成朝下；`Action.LEFT` 变成朝上；`STRAIGHT` 不变。

### 3.2 碰撞判定

```python
wall_collision = not self._in_bounds(new_head)
eating = (not wall_collision) and self.food is not None and new_head == self.food
body_to_check = self.snake if eating else self.snake[:-1]
self_collision = (not wall_collision) and new_head in body_to_check
```

三个细节：

1. **先判墙**，越界就不再检查身体；
2. **是否吃到食物**决定尾巴是否腾出；
3. **非进食时检查 `snake[:-1]`**，排除尾巴。因为尾巴这一步会离开。

### 3.3 死亡

```python
if wall_collision or self_collision:
    self._terminated = True
    reason = "wall" if wall_collision else "self"
    info = self._info(death_reason=reason, attempted_head=new_head)
    return StepOutcome(self.state, death_reward, True, False, info)
```

注意：**蛇头没有真的移动到越界/重叠的位置**。返回的状态仍然是合法棋盘，
`info["attempted_head"]` 记录了“它本来想走到哪”。

为什么这样做？

- 渲染不会越界；
- 测试可以断言“死亡后蛇身仍然合法”；
- DQN 在 `terminated=True` 时不会用 `next_state` 做 bootstrap，所以不影响学习。

### 3.4 移动、吃食物、放尾巴

```python
self.direction = new_direction
self.snake.insert(0, new_head)

if eating:
    self.score += 1
    self.steps_since_food = 0
    reward += food_reward
    if not self._place_food():
        terminated = True
        info["win"] = True
else:
    self.snake.pop()
```

- 吃到食物：头插入，尾巴保留，蛇变长；
- 没吃到：头插入，尾巴弹出，长度不变；
- 棋盘填满：`_place_food()` 返回 False，`food=None`，`terminated=True`，`info["win"]=True`。

### 3.5 超时

```python
step_limit = max_steps_without_food_factor * len(self.snake)
if not terminated and self.steps_since_food > step_limit:
    truncated = True
    reward += timeout_reward
    info["timeout"] = True
```

为什么用 `steps_since_food` 而不是总步数？

- 总步数会让“活得久”本身变成被截断的理由；
- 参考项目就有一个隐藏问题：吃完食物后 `frame_iteration` 不重置，
  长 episode 可能在刚吃完后突然结束；
- 用“距上次吃食物”更符合“给蛇足够时间去找下一顿”的直觉。

上限随蛇长增长：蛇越长，绕路和转身越困难，允许更多步。

---

## 4. 其他设计决定

### 4.1 食物从空格子均匀采样

```python
occupied = set(self.snake)
empty = [
    Point(x, y)
    for y in range(self.config.height)
    for x in range(self.config.width)
    if (x, y) not in occupied
]
if not empty:
    self.food = None
    return False
self.food = self.rng.choice(empty)
```

对比参考项目的递归重试：

```python
self.food = Point(x, y)
if self.food in self.snake:
    self._place_food()
```

递归在棋盘快满时可能很深，棋盘满时无限递归。我们直接枚举空格子，顺便处理胜利。

### 4.2 坐标用格子，不用像素

- 状态、碰撞、距离都是整数；
- 渲染时才乘 `cell_size`；
- 换棋盘大小不需要改逻辑。

参考项目用像素浮点数（`w/2`），能跑，但多了不必要的单位转换。

### 4.3 `will_collide` 辅助函数

```python
def will_collide(self, direction: Direction, *, ignore_tail: bool = True) -> bool:
    next_head = self._next_head(self.head, direction)
    if not self._in_bounds(next_head):
        return True
    body = self.snake[:-1] if ignore_tail else self.snake
    return next_head in body
```

Stage 1 的 11 维观察需要“前/右/左是否危险”三个 bit。这个函数把碰撞逻辑留在环境里，
observation 只负责组装特征，不重复实现规则。

### 4.4 `relative_action`

人类试玩按方向键（绝对方向），环境接收相对动作。这个函数负责翻译：

```python
relative_action(Direction.RIGHT, Direction.DOWN)  # Action.RIGHT
relative_action(Direction.RIGHT, Direction.UP)    # Action.LEFT
relative_action(Direction.RIGHT, Direction.LEFT)  # None（不能掉头）
```

返回 `None` 表示这个绝对方向与当前朝向相反，人类脚本会忽略这次输入。

---

## 5. 配置

`EnvConfig` 的默认值：

| 参数                            | 默认值 | 说明                     |
| ------------------------------- | -----: | ------------------------ |
| `width`, `height`               | 20, 20 | 棋盘格子数               |
| `initial_length`                |      3 | 初始蛇长                 |
| `max_steps_without_food_factor` |    100 | 超时上限 = factor × 蛇长 |
| `food_reward`                   |   10.0 | 吃食物                   |
| `death_reward`                  |  -10.0 | 撞墙/撞自己              |
| `step_reward`                   |    0.0 | 每步                     |
| `timeout_reward`                |    0.0 | 超时                     |
| `win_reward`                    |    0.0 | 填满棋盘                 |

死亡这一步的总奖励是 `step_reward + death_reward`；默认 `step_reward=0`，所以就是 -10。
吃食物、超时、胜利同理：事件奖励都会叠加到当步的 `step_reward` 上。

如果想在 Stage 1 更接近参考项目的奖励：

```python
EnvConfig(
    food_reward=10.0,
    death_reward=-10.0,
    timeout_reward=-10.0,
    max_steps_without_food_factor=100,
)
```

但注意：我们的超时仍然是 `truncated`。如果训练器把 `truncated` 当成 `terminated`，
就复刻了参考项目的偏差；Stage 2 会修掉。Stage 1 为了对照，可以**临时**这样做，
但要明确记录。

---

## 6. 渲染与人类试玩

```powershell
.\.venv\Scripts\python.exe scripts\play_human.py
```

操作：

- 方向键 / WASD：转向；
- R：重开；
- Esc：退出。

渲染器的几个细节：

- `pygame.display.init()` + `pygame.font.init()`，不调用 `pygame.init()`（避免初始化音频）；
- HUD 分两行：第一行分数/步数/长度，第二行状态；
- 窗口窄时自动用更小字号；
- 蛇头画眼睛，方便看朝向；
- 食物是圆点，蛇身是圆角矩形。

训练时**不要创建渲染器**。它只用于人类试玩和演示。

---

## 7. 随机基线实验

命令：

```powershell
# 20x20，默认 timeout factor=100
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0

# 10x10
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0 --width 10 --height 10

# 更紧的 timeout
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0 --timeout-factor 10
```

PowerShell 里如果想换行，用反引号 `` ` ``；上面的命令都写成了一行。

下面是实际结果（100 局，seed=0）：

| 棋盘  | timeout factor | 平均分 | 中位数 | 最高分 | 平均步数 | 结束方式             |
| ----- | -------------: | -----: | -----: | -----: | -------: | -------------------- |
| 20×20 |            100 |   0.11 |    0.0 |      2 |     74.1 | wall 99 / self 1     |
| 10×10 |            100 |   0.21 |    0.0 |      2 |     18.1 | wall 100             |
| 20×20 |             50 |   0.14 |    0.0 |      1 |     73.3 | wall 94 / timeout 6  |
| 20×20 |             10 |   0.04 |    0.0 |      2 |     29.8 | timeout 79 / wall 21 |
| 10×10 |             10 |   0.14 |    0.0 |      1 |     17.3 | wall 87 / timeout 13 |

### 怎么读这张表

1. **随机策略几乎学不到东西**：平均分 0.04–0.21，绝大多数局是 0 分。
   这是后面 DQN 要超过的下界。
2. **20×20 平均步数更长，但分数没有更高**：随机乱走只是“活得久”，
   不是“更会找食物”。所以不能只看 episode 长度。
3. **timeout factor 会改变结束方式**：
   - 20×20 + factor 10：79% 被截断，因为蛇在 30 步内很少撞墙；
   - 10×10 + factor 10：只有 13% 被截断，因为小棋盘上随机走更容易撞墙。
     棋盘大小、蛇长和 timeout 是耦合的，不能单独调一个。
4. **随机 agent 几乎不会 self**：它很少长到能咬到自己。等 DQN 学会吃食物后，
   self collision 才会变多，这是观察学习进展的一个指标。

> 这些数字只来自一个 seed、100 局。它们的用途是“下界”和“流程验证”，
> 不是统计结论。Stage 1 开始要跑多个 seed 并报告方差。

---

## 8. 测试

```powershell
.\.venv\Scripts\python.exe -m pytest
```

实际输出：

```
...............                                                          [100%]
15 passed
```

测试覆盖：

| 组     | 测试                                                     |
| ------ | -------------------------------------------------------- |
| 初始化 | 初始长度/位置/食物不在蛇身；seed 可复现；食物不刷在蛇身  |
| 动作   | 直行/右转/左转的方向和头位置；`relative_action` 映射     |
| 碰撞   | 撞墙终止；撞自己终止；走进腾出的尾巴安全                 |
| 食物   | 吃食物加分、变长、刷新食物、`steps_since_food` 归零      |
| 超时   | 超时是 `truncated` 不是 `terminated`；结束后再 step 抛错 |
| 确定性 | 同 seed + 同动作序列 → 同轨迹                            |
| 配置   | 非法宽高/初始长度/timeout factor 被拒绝                  |

这些测试不验证“RL 学得好不好”，只验证**规则实现是否符合设计**。后面改奖励、
改观察、改超时，都应该先保证这些基础测试仍然通过。

---

## 9. 与参考项目的差异

| 方面      | 参考项目                                 | 我们                                                       |
| --------- | ---------------------------------------- | ---------------------------------------------------------- |
| 逻辑/渲染 | `game.py` 耦合                           | `snake_env.py` / `renderer.py` 分离                        |
| 坐标      | 像素浮点                                 | 格子整数                                                   |
| 环境 API  | `play_step` 返回 `(reward, done, score)` | `step` 返回 `(state, reward, terminated, truncated, info)` |
| 动作      | one-hot                                  | 整数 0/1/2                                                 |
| 尾巴碰撞  | 包含尾巴，偏保守                         | 非进食时排除尾巴                                           |
| 死亡状态  | 头已插入，可能越界/重叠                  | 保持合法，记录 `attempted_head`                            |
| 超时      | 总步数，-10，视为终止                    | 距上次吃食物，默认 0，`truncated`                          |
| 食物放置  | 递归重试                                 | 枚举空格子，处理胜利                                       |
| 随机种子  | 无                                       | `seed` 可复现                                              |
| 训练渲染  | 每步渲染 + 40 FPS                        | headless，渲染只在试玩/演示                                |
| 训练循环  | 有                                       | 还没有（Stage 1）                                          |
| 测试      | 无                                       | 15 个                                                      |

---

## 10. 自测题

<details>
<summary>1. 为什么 `env.step` 在 episode 结束后要抛错，而不是自动 reset？</summary>

自动 reset 会隐藏“忘记处理终止”的 bug。显式抛错强制调用方决定：是记录结果并 reset，
还是继续用旧状态。训练循环里终止/截断的处理是核心逻辑，不能悄悄替用户做。
</details>

<details>
<summary>2. 撞死时 `steps` 和 `steps_since_food` 会增加吗？返回状态里它们是多少？</summary>

会。我们在碰撞判定之前就递增了计数器。返回状态的蛇身/食物/分数不变，但
`steps` 和 `steps_since_food` 已经加 1。这符合“这一步已经尝试过了”的语义。
</details>

<details>
<summary>3. 为什么测试撞墙时只比较 `state.snake`，不比较整个 `state`？</summary>

因为 `steps` 在碰撞时已经增加，整个 `SnakeState` 不相等。我们关心的是棋盘没有被破坏，
所以比较 `snake` 和 `head`。
</details>

<details>
<summary>4. `will_collide(ignore_tail=True)` 的 `ignore_tail` 是什么意思？</summary>

非进食时尾巴会腾出，所以检查身体时排除尾巴。`ignore_tail=False` 用于“这一步会吃食物、
尾巴不腾”的情况；不过食物不会刷在蛇身上，所以实践中很少需要。
</details>

<details>
<summary>5. 为什么 `initial_length` 在配置阶段就校验？</summary>

初始蛇水平向左延伸，头在 `width//2`。如果长度超过 `width//2 + 1`，身体会越界。
早失败比运行到一半出现非法状态好。
</details>

<details>
<summary>6. `food=None` 什么时候出现？</summary>

棋盘被蛇填满，`_place_food` 找不到空格子，返回 False；此时 `food=None`，
`terminated=True`，`info["win"]=True`。渲染器会跳过食物绘制。
</details>

<details>
<summary>7. 随机 agent 为什么每局用 `env.reset(seed=args.seed + episode)`？</summary>

让每局的食物序列由 episode 编号决定，整次实验可复现；同时不同局之间又有不同的随机性。
动作随机数用单独的 `random.Random(args.seed)`，和环境随机性分开。
</details>

<details>
<summary>8. 为什么 20×20 随机 agent 平均步数更长，但平均分没有明显更高？</summary>

随机策略没有“朝食物走”的倾向。棋盘越大，撞墙前能走的步数越多，但每一步仍然近似随机，
吃到食物的概率没有因此提高。步数衡量的是“存活”，分数衡量的是“目标导向”，两者不是一回事。
</details>

---

## 11. 下一阶段准备（已完成）

Stage 1 新增了：

```
snake_rl/env/observations.py     # 11 维特征
snake_rl/models/qnet.py          # 11 -> 256 -> 3
snake_rl/agents/dqn.py           # epsilon-greedy + replay + train_step
snake_rl/training/train_dqn.py   # headless 训练 + CSV 日志
scripts/evaluate.py              # greedy 评估
```

训练依赖已经安装（CPU 版）：

```powershell
# CPU 版（推荐先跑通）
uv pip install --python .\.venv\Scripts\python.exe torch --index-url https://download.pytorch.org/whl/cpu
uv pip install --python .\.venv\Scripts\python.exe matplotlib tqdm
```

实现顺序（已完成）：

1. 写 `observations.py`，用测试验证 11 位与参考项目一致；
2. 写 `QNet`，确认输入/输出形状；
3. 写 replay buffer 和 `train_step`，先用手工构造的小 batch 验证 target；
4. 写训练循环，先跑 10 局确认不崩；
5. 跑 500 局，记录曲线；
6. 用 greedy 评估 100 局，对比随机基线；
7. 写实验记录，再进入 Stage 2。

详细讲解见 [04-stage1-dqn-baseline.md](04-stage1-dqn-baseline.md)。

---

## 12. 实验记录

本次结果已经记在 [`logs/stage0-random-baseline.md`](logs/stage0-random-baseline.md)；
你可以复制 [`lab-log-template.md`](lab-log-template.md) 补充自己机器上的数据。至少回答：

- 你的机器上跑 100 局花了多少秒？
- 20×20 和 10×10 的结束方式分布为什么不同？
- timeout factor 从 100 降到 10，截断率怎么变？这和你的预期一致吗？

下一步：Stage 1 已实现（见 [04-stage1-dqn-baseline.md](04-stage1-dqn-baseline.md)），
接着进入 Stage 2，修目标网络、Double DQN、Huber 和 truncation bootstrap。
