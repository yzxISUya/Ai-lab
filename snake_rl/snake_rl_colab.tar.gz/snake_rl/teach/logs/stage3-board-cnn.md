# 实验：Stage 3 全棋盘 CNN 首次训练

- **日期**：2026-10-27
- **目标**：把完整 20×20 棋盘作为观察，用 CNN 从零学习 Snake。
- **算法**：目标网络 + Double DQN，MSE，`bootstrap_truncated=False`。
- **观察**：`(5, 20, 20)`：body / head / tail / food / border。
- **网络**：`BoardQNet`（3 层 conv + FC，约 1.70M 参数）。
- **设备**：RTX 5060 Laptop，CUDA 13.0，torch 2.14.1+cu130。
- **更新方式**：replay minibatch，batch 128/256，每 2 个环境步更新一次。

---

## Run 1：500 局短训练

- 命令参数：500 局，batch 128，replay 20k，epsilon 0.4→0.02 / 150 局。
- 结果：
  - 64,367 步，222 秒（约 290 步/秒）。
  - 31,684 replay updates，31 次 target sync。
  - 最终 100 局 eval：**mean 0.17 / median 0 / max 2 / std 0.40**。
  - 死因：wall 56 / timeout 44 / self 0。
- 结论：几乎没学会找食物，但还没完全退化成绕圈。

## Run 2：更长训练（45 分钟）

- 参数：最多 5000 局，batch 256，replay 50k，
  epsilon 0.4→0.05 / 1500 局，每 500 局 eval。
- 实际跑到约 **2486 局**，45 分钟超时（SIGINT），保存 checkpoint。
- 训练统计：
  - **484,183 步**，2697 秒（约 179 步/秒）。
  - 训练 score：mean 0.101，max 2；2486 局中只有 233 局拿过分。
  - 死因：wall 1261 / timeout 1212 / self 13 / win 0。
  - 最近 200 局：mean score 0.07，timeout 187 / wall 12。
  - 最后 epsilon = 0.05，target_syncs = 241。
- 最终 100 局 eval（seed=20_000，GPU）：
  - **mean 0.00，median 0，max 0，std 0.00，mean steps 301.0**
  - **endings: timeout 100 / 100**
- 结论：策略完全退化成“绕圈到超时”，比 Run 1 更差。

---

## 诊断

1. **稀疏奖励 + 全棋盘，样本复杂度远高于 11 维特征。**
   11 维观察直接告诉 agent 食物方向和一格危险；CNN 必须自己学“食物在哪、怎么走过去”。
   在 48 万步内没有学出来。

2. **绕圈是一个稳定的局部最优。**
   timeout 惩罚是 -10，和撞死一样；但绕圈可以避免撞墙，而且惩罚延迟到 301 步。
   agent 学会了“安全地活到超时”，但没有正奖励把它拉向食物。

3. **epsilon 太低，无法逃离局部最优。**
   长训练在 1500 局后 epsilon 到 0.05；此时策略已经退化成绕圈，
   5% 随机动作不足以重新发现食物。

4. **更多训练没有帮助，反而更差。**
   Run 1（500 局）eval 0.17；Run 2（2486 局）eval 0.00。
   说明问题不是单纯“训练时间不够”，而是探索/奖励/课程设计。

5. **全棋盘 CNN 不是不能用，而是需要更合适的训练方案。**
   直接 20×20 + 稀疏奖励 + 1 小时，不足以从零学会。

---

## 修复的 bug

评估 CUDA checkpoint 时发现：

- `cuda_rng_state` 在 `map_location='cuda'` 下被映射成 CUDA tensor；
- `torch.cuda.set_rng_state_all` 要求 CPU ByteTensor。

已在 `DQNAgent.load` 中把每个 RNG state 移到 CPU；新增 CUDA checkpoint roundtrip 测试。
**55 个测试全部通过。**

---

## 下一步候选

1. **课程学习（推荐，仍然纯 RL）**
   - 先 8×8 或 10×10 棋盘，食物更容易撞到；
   - 用同样的全棋盘 CNN、同样的算法；
   - 学会找食物后再扩到 20×20（FC 尺寸会变，需要重训或改成全卷积+global pooling）。
   - 10×10、1500 局大概 10–15 分钟，适合先验证。

2. **更高 epsilon / 更强 timeout 惩罚**
   - epsilon 下限 0.1–0.2，衰减更慢；
   - timeout reward 改得更负（例如 -20），或缩短 timeout，打破“绕圈安全”的局部最优。
   - 这会改变奖励/探索设计，不再是完全原始的 Stage 3 设定。

3. **奖励塑形**
   - potential-based shaping，例如 `Phi(s) = -BFS 距离`；
   - 理论上保持最优策略，但注入领域知识；和“纯 RL”目标有冲突。

4. **更多算力/更长训练**
   - 全棋盘 CNN 可能需要数小时到数天，不是 1 小时能解决的；
   - 需要先解决探索/局部最优，否则加时间只会更稳定地绕圈。

5. **观察工程**
   - 加距离/坐标/食物中心通道，或改成局部 patch + 射线；
   - 这不是纯全棋盘，但样本效率会高很多。

---

## 结论

**一小时内的全棋盘 CNN + 稀疏奖励没有学会 Snake。**
它学到了“绕圈到超时”的局部最优，而不是找食物。
下一步最有价值的是 **小棋盘课程学习**，而不是继续在 20×20 上堆时间。
