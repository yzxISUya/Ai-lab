# 实验：Stage 0 随机策略基线

- **日期**：2026-10-25
- **阶段**：Stage 0
- **代码版本**：Stage 0 初始骨架
- **假设**：
  1. 均匀随机策略的平均分接近 0，只能作为下界；
  2. 20×20 上随机 agent 的平均步数会比 10×10 长，但平均分不会明显更高；
  3. timeout factor 变小时，20×20 上的截断率会明显上升，10×10 上则仍以撞墙为主。
- **改动**：无（基线）。
- **配置**：
  - 棋盘：20×20 / 10×10
  - 初始蛇长：3
  - timeout factor：100 / 50 / 10
  - 奖励：food +10，death -10，step 0，timeout 0
  - 训练：无
  - 评估：随机策略，100 局，seed=0
- **命令**：

```powershell
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0 --width 10 --height 10
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0 --timeout-factor 50
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0 --timeout-factor 10
.\.venv\Scripts\python.exe scripts\random_agent.py --episodes 100 --seed 0 --width 10 --height 10 --timeout-factor 10
```

- **种子**：环境/食物 seed = `0 + episode`；动作 seed = 0
- **耗时**：每组 < 1 秒（headless）

---

## 结果

| 棋盘  | timeout factor | 平均分 | 中位数 | 最高分 | 平均步数 | 结束方式             |
| ----- | -------------: | -----: | -----: | -----: | -------: | -------------------- |
| 20×20 |            100 |   0.11 |    0.0 |      2 |     74.1 | wall 99 / self 1     |
| 10×10 |            100 |   0.21 |    0.0 |      2 |     18.1 | wall 100             |
| 20×20 |             50 |   0.14 |    0.0 |      1 |     73.3 | wall 94 / timeout 6  |
| 20×20 |             10 |   0.04 |    0.0 |      2 |     29.8 | timeout 79 / wall 21 |
| 10×10 |             10 |   0.14 |    0.0 |      1 |     17.3 | wall 87 / timeout 13 |

### 和基线对比

| 版本              | 评估均分 | 中位数 | 最高分 | 备注 |
| ----------------- | -------: | -----: | -----: | ---- |
| 随机策略（20×20） |     0.11 |    0.0 |      2 | 下界 |
| 随机策略（10×10） |     0.21 |    0.0 |      2 | 下界 |

---

## 观察

- 随机策略绝大多数局得 0 分，少数局吃到 1–2 个食物。
- 20×20 上平均步数约 74，10×10 上约 18；大棋盘让随机游走“活得更久”。
- 但 20×20 的平均分并没有比 10×10 高，说明“活得久”不等于“会找食物”。
- timeout factor=10 时，20×20 有 79% 的局被截断；10×10 只有 13%，因为小棋盘上更容易撞墙。
- 随机 agent 几乎不会 self collision：蛇太短，很少有机会咬到自己。

## 解释

- 随机策略没有目标导向，吃到食物主要靠偶然；棋盘越大，单步碰到食物的概率越低，
  但存活步数越长，两者大致抵消，所以平均分都很低。
- timeout 和棋盘大小强耦合：同样的步数上限，在大棋盘上更容易“还没撞墙就被截断”，
  在小棋盘上更容易“先撞墙”。
- 因此后面调 timeout 时，必须同时报告截断率和死因分布，不能只看分数。

## 下一步

- [ ] Stage 1：实现 11 维观察、QNet、replay、训练循环；
- [ ] 用 greedy 评估 100 局，和这张表对比；
- [ ] 训练曲线同时记录 score、mean100、loss、epsilon、steps、死因；
- [ ] 先跑 seed=0，确认流程，再加 seed=1/2。

## 复现

见上面的命令。注意：结果对 `--episodes`、`--seed`、棋盘大小和 timeout factor 都敏感；
对比时必须保持这些参数一致。
