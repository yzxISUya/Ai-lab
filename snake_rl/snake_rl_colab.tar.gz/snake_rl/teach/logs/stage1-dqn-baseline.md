# 实验：Stage 1 DQN 基线

- **日期**：2026-10-25
- **阶段**：Stage 1
- **代码版本**：Stage 1 初始实现
- **假设**：
  1. 在 20×20、500 局的规模下，greedy 评估均分会高于随机基线的 0.11；
  2. 训练时的 epsilon-greedy score 会高于 greedy eval，因为前者带探索；
  3. 没有目标网络 + MSE 会出现 loss 波动、Q 值偏高，greedy 策略可能偏向“安全绕圈”。
- **改动**：无（Stage 1 基线）。
- **配置**：
  - 棋盘：20×20
  - 初始蛇长：3
  - timeout factor：100（上限 = 100 × 蛇长）
  - 奖励：food +10，death -10，step 0，timeout -10
  - 观察：11 维
  - 网络：11 → 256 → 3，ReLU
  - lr：1e-3
  - gamma：0.9
  - batch size：1000
  - replay：100k
  - epsilon：0.4 → 0，80 局
  - short memory：每步单样本更新
  - long memory：每局 replay batch 更新
  - bootstrap_truncated：False（Stage 1 故意复刻参考项目）
  - 训练：500 局
  - 评估：每 50 局 20 局；最终 100 局，greedy
- **命令**：

```powershell
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 --eval-every 50 --eval-episodes 20 --final-eval-episodes 100 --checkpoint-every 100 --log-every 25 --output-dir runs\stage1_seed0
.\.venv\Scripts\python.exe scripts\evaluate.py --run-dir runs\stage1_seed0 --episodes 100
.\.venv\Scripts\python.exe scripts\plot_training.py --run-dir runs\stage1_seed0
```

- **种子**：
  - 训练：0
  - 环境/食物：`seed + episode`，episode 从 1 开始
  - 动作/replay：由 seed=0 派生
  - 评估：训练中 `10_000 + i`；最终 `20_000 + i`
- **设备**：CPU（torch 2.14.1+cpu）

---

## 结果

### 最终 500 局 greedy 评估

训练：**189,708 步，922.3 秒，约 205.7 步/秒**（约 15.4 分钟）。

最终评估（100 局，seed=20_000 起）：

| 指标                        |             值 |
| --------------------------- | -------------: |
| mean                        |      **27.14** |
| median                      |           26.0 |
| max                         |             52 |
| min                         |              1 |
| std                         |          10.13 |
| mean steps                  |         405.44 |
| score/step                  |         0.0669 |
| wall / self / timeout / win | 5 / 95 / 0 / 0 |

独立复核（100 局，seed=10_000 起，重新加载 checkpoint）：

| 指标                        |             值 |
| --------------------------- | -------------: |
| mean                        |          27.21 |
| median                      |           27.5 |
| max                         |             61 |
| min                         |              5 |
| std                         |          11.88 |
| mean steps                  |          410.0 |
| score/step                  |         0.0664 |
| wall / self / timeout / win | 1 / 99 / 0 / 0 |

两次 100 局评估的均值几乎一致（27.14 vs 27.21），说明 checkpoint 和评估流程是稳定的。
结果文件：

- `runs/stage1_seed0/final_eval.json`（seed=20_000）
- `runs/stage1_seed0/eval.json`（seed=10_000）
- `runs/stage1_seed0/summary.json`
- `runs/stage1_seed0/curve.png`
- 本文档旁的 [`stage1_curve.png`](stage1_curve.png)

### 训练过程中的 greedy eval（20 局）

| episode |  mean | median | max | min |   std | mean steps | 结束方式         |
| ------: | ----: | -----: | --: | --: | ----: | ---------: | ---------------- |
|      50 |  0.55 |    0.5 |   2 |   0 |  0.60 |      367.3 | timeout 20       |
|     100 | 25.20 |   23.5 |  53 |  11 | 10.61 |      369.2 | self 19 / wall 1 |
|     150 | 26.50 |   25.5 |  45 |  11 |  8.68 |      380.6 | self 20          |
|     200 | 28.85 |   29.5 |  55 |  12 | 12.53 |      441.9 | self 20          |
|     250 | 30.30 |   31.0 |  46 |  12 | 10.42 |      454.6 | self 20          |
|     300 | 23.85 |   21.5 |  34 |  12 |  6.60 |      353.6 | self 20          |
|     350 | 25.90 |   22.5 |  57 |  12 | 10.95 |      374.6 | self 20          |
|     400 | 32.60 |   33.0 |  51 |  19 |  9.51 |      478.1 | self 20          |
|     450 | 25.70 |   26.0 |  43 |  16 |  6.39 |      361.0 | self 20          |
|     500 | 29.60 |   31.0 |  53 |   5 | 13.35 |      433.6 | self 19 / wall 1 |

20 局评估的波动很大（23.85–32.60），不能只看某一次；最终 100 局的 27.14 更可靠。

### 50 局开发实验（只用于跑通流程）

| episode | train score | mean100 | epsilon | greedy eval mean | eval 结束方式 |
| ------: | ----------: | ------: | ------: | ---------------: | ------------- |
|      10 |           1 |    0.20 |   0.355 |                — | —             |
|      25 |           1 |    0.52 |   0.280 |             0.00 | timeout 20    |
|      50 |           1 |    0.86 |   0.155 |             0.55 | timeout 20    |

50 局时 20 局 greedy eval 全部 timeout、mean 0.55；训练 4744 步，29.2 秒。
**这个阶段的结论不能外推**：完整训练到 100 局时，greedy eval 已经到 25.20。

### 曲线

![Stage 1 训练曲线](stage1_curve.png)

四张图分别是：

- 左上：训练 score、mean100、greedy eval mean。50–100 局之间出现明显跃升，
  之后 mean100 在 25–30 左右平台化；20 局 eval 在 23.85–32.60 之间波动。
- 右上：short/long loss。数值在 3–5 左右波动，没有爆炸；MSE 的绝对值和评估分数
  不能直接对应。
- 左下：epsilon。第 80 局降到 0，之后训练仍继续改善，直到约 175 局进入平台。
- 右下：episode 长度。从早期几十步增长到 400–600 步，说明蛇活得更久、身体更长。

### 和基线对比

| 版本                        | 评估局数 | 平均分 | 中位数 | 最高分 | 标准差 | 结束方式         |
| --------------------------- | -------: | -----: | -----: | -----: | -----: | ---------------- |
| 随机策略（20×20）           |      100 |   0.11 |    0.0 |      2 |   0.35 | wall 99 / self 1 |
| Stage 1（500 局，seed 20k） |      100 |  27.14 |   26.0 |     52 |  10.13 | self 95 / wall 5 |
| Stage 1（500 局，seed 10k） |      100 |  27.21 |   27.5 |     61 |  11.88 | self 99 / wall 1 |

> 随机基线和 DQN 评估使用不同的种子集合，不能做严格的逐局配对比较；
> 但 0.11 → 27.14 的差距远大于评估噪声，学习是真实发生的。

---

## 观察

- **50–100 局之间出现跃升**：greedy eval 从 0.55 跳到 25.20。早期“全 timeout”
  不是算法不会学，而是训练不够。
- **mean100 在 175 局后平台化**：大约 25–30；最终 100 局 eval 27.14。
- **20 局评估噪声很大**：同一策略在 300 局时 eval 23.85，400 局时 32.60。
  这说明评估局数太少时，不要把单次波动当成算法改进或退化。
- **主要死因是 self collision**：最终 100 局中 95 局 self，只有 5 局 wall。
  蛇变长后，11 维观察看不到身体形状，这是明显的瓶颈。
- **loss 稳定**：MSE 在 3–5 左右波动，没有爆炸或 NaN；但 loss 不下降不代表策略没变好，
  Q 值尺度和目标在变，loss 的绝对值不能直接解读。
- **epsilon 归零后仍在学习**：第 80 局 epsilon=0，但 replay + short memory 继续更新，
  策略到约 175 局才进入平台。说明探索不是唯一的改进来源。

## 解释

- DQN 学会了“找食物 + 变长”；随后主要失败模式从撞墙变成自撞。
  这不是优化器发散，而是**观察/策略上限**：11 维观察没有距离和身体形状。
- 没有目标网络 + MSE 在这个设置下没有导致明显发散，但可能贡献了 eval 的方差。
  是否值得加目标网络，要用 Stage 2 的同一评估协议来量。
- 50 局开发实验的“全 timeout”是一个很好的教训：**短跑不能用来判断 DQN 是否学会**。
- 20 局 eval 的波动说明：Stage 2 的消融至少用 100 局评估，最好多种子。

## 结论

> 在 11 维观察、无目标网络、MSE、epsilon 80 局衰减的设置下，500 局后
> greedy eval mean **27.14**、median 26、max 52、std 10.13；
> 主要失败模式是 self collision（95/100）；loss 稳定在 3–5，无爆炸。
>
> 这是一个可用的 Stage 1 基线，也是 Stage 2 的对照点。
> 但平台化和 self collision 说明：**更大的杠杆可能在 Stage 3 的观察工程**，
> 而不是继续堆 DQN 技巧。

## 下一步

- [ ] Stage 2：先只开 `bootstrap_truncated=True`，跑 500 局
- [ ] Stage 2：加目标网络，比较稳定性和 100 局 eval
- [ ] Stage 2：Double DQN、Huber、梯度裁剪、epsilon 调度
- [ ] Stage 2：标准 replay minibatch 更新 vs short memory
- [ ] Stage 2：至少 seed=0/1/2 重复，报告均值 ± 方差
- [ ] Stage 3：距离特征 / 射线 / 网格 CNN / 奖励塑形

## 复现

见上面的命令。`runs/` 已在 `.gitignore` 中；本文档保留了关键数字和曲线。
如果需要完整日志，复制：

```
runs/stage1_seed0/train.csv
runs/stage1_seed0/eval.csv
runs/stage1_seed0/final_eval.json
runs/stage1_seed0/eval.json
runs/stage1_seed0/summary.json
runs/stage1_seed0/curve.png
```

到 `teach/logs/` 或单独的 experiment 目录。
