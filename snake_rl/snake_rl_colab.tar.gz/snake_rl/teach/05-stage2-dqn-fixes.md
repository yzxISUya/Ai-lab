# 05 · Stage 2：修 DQN 与消融

Stage 1 已经给出一个能学的基线。Stage 2 的目标不是“把所有技巧都加上”，而是：

> **一次只改一个东西，跑同一套评估，回答“这个改动到底有没有用”。**

参考项目里那些“看起来应该加”的东西——目标网络、Double DQN、Huber、正确的
truncation——都要在这里逐个验证。不要一次性全加。

---

## 1. Stage 1 基线回顾

完整 500 局结果见 [`logs/stage1-dqn-baseline.md`](logs/stage1-dqn-baseline.md)。
开发过程中已经观察到的现象：

| episode | greedy eval mean | eval 结束方式    | 备注                 |
| ------: | ---------------: | ---------------- | -------------------- |
|      50 |             0.55 | timeout 20       | 还不会找食物         |
|     100 |            25.20 | self 19 / wall 1 | 已经能吃到很多食物   |
|     150 |            26.50 | self 20          | 蛇变长后主要死于自撞 |

完整 500 局最终结果（100 局 greedy eval，seed=20_000 起）：

| 指标        |        值 |
| ----------- | --------: |
| mean        | **27.14** |
| median      |      26.0 |
| max         |        52 |
| std         |     10.13 |
| self / wall |    95 / 5 |

训练 189,708 步、约 15.4 分钟；mean100 在 175 局后平台化在 25–30；
loss 在 3–5 左右波动，没有爆炸。

这组数字说明三件事：

1. **不要用 50 局下结论**。DQN 可能在 50–100 局之间突然“开窍”。
2. 后期的主要瓶颈是 **self collision**，不是撞墙。这更像是观察/策略问题，
   而不是单纯的优化器问题。Stage 2 的算法修正可能只带来小幅提升；
   更大的杠杆可能在 Stage 3 的观察工程。
3. 20 局评估的波动很大（23.85–32.60），Stage 2 的消融至少用 100 局评估。

> 先把 Stage 2 做扎实：它的价值不只是分数，而是让你能解释每个组件的作用。

---

## 2. 实验纪律

每个版本都要满足：

- 同一棋盘、同一 timeout、同一奖励；
- 同一组训练种子（先 seed=0，稳定后加 1/2）；
- 同一组评估种子（训练中 10_000 起，最终 20_000 起）；
- 500 局训练，100 局 greedy 评估；
- 只改一个变量；如果改了多个，拆开重跑；
- 记录 `eval mean/median/max/std`、结束方式、平均步数、loss、训练耗时。

---

## 3. 修正 1：truncation bootstrap（P0）

### 问题

Stage 1 默认：

```python
done = terminated | truncated
target = r + gamma * next_q * (~done)
```

超时被当成终止，未来价值被砍掉。正确语义是：

- 撞墙/撞自己/胜利：`terminated=True`，target = `r`；
- 超时：`truncated=True`，target = `r + γ max Q_target(s')`。

### 代码已经留好的开关

`DQNConfig.bootstrap_truncated` 已经存在，`compute_targets` 已经支持：

```python
done = terminated if self.config.bootstrap_truncated else (terminated | truncated)
```

### 第一个实验（不需要写代码）

```powershell
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 --bootstrap-truncated `
    --output-dir runs\stage2_b_trunc_seed0
```

### 要观察什么

- greedy eval 是否变化？
- timeout 比例是否变化？如果 agent 更愿意绕圈，timeout 可能上升；
- loss / Q 值是否变得更乐观；
- 结论是“正确性修正”，不保证一定提分。

> 这一步很重要：**正确性和性能不是一回事**。即使分数没涨，这个修正也应该保留。

---

## 4. 修正 2：目标网络（P0）

### 为什么

Stage 1 的 target 用的是正在训练的在线网络：

$$
y = r + \gamma \max_{a'} Q_\theta(s',a')
$$

每次更新都会改变 target，网络在追一个自己不断移动的目标。目标网络用一套延迟更新的
参数 $\theta^-$：

$$
y = r + \gamma \max_{a'} Q_{\theta^-}(s',a')
$$

### 建议实现

`DQNConfig` 加：

```python
use_target_network: bool = False
target_sync_every: int = 1000   # 每多少次 train_step 同步一次
```

`DQNAgent.__init__`：

```python
self.target_model = QNet(...).to(self.device)
self.target_model.load_state_dict(self.model.state_dict())
self.target_model.eval()
self.updates = 0
```

`sync_target`：

```python
def sync_target(self) -> None:
    self.target_model.load_state_dict(self.model.state_dict())
```

`compute_targets`：

```python
target_net = self.target_model if self.config.use_target_network else self.model
with torch.no_grad():
    next_q = target_net(next_obs).max(dim=1).values
```

`train_step` 末尾：

```python
self.updates += 1
if self.config.use_target_network and self.updates % self.config.target_sync_every == 0:
    self.sync_target()
```

checkpoint 要同时保存/加载 `target_model`。

### 测试

- 初始化时在线网络与目标网络参数相同；
- `train_step` 后在线网络变了，目标网络没变；
- 调用 `sync_target` 后两者再次相同。

### 实验

```powershell
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 `
    --bootstrap-truncated --use-target-network `
    --output-dir runs\stage2_c_target_seed0
```

### 要观察什么

- loss 是否更平稳？
- greedy eval 的方差是否下降？
- `target_sync_every` 太短 ≈ 没有目标网络；太长 ≈ target 过时。可以先试 1000 次更新。

---

## 5. 修正 3：Double DQN（P1）

### 为什么

普通 Q-learning 的 max 会系统性高估 Q 值。Double DQN 把“选动作”和“评估动作”分开：

- 用在线网络选动作：$a^* = \arg\max_a Q_\theta(s',a)$；
- 用目标网络评估：$Q_{\theta^-}(s',a^*)$。

### 建议实现

`DQNConfig` 加 `double_dqn: bool = False`。

`compute_targets`：

```python
target_values = target_net(next_obs)          # (B, 3)
if self.config.double_dqn:
    next_actions = self.model(next_obs).argmax(dim=1, keepdim=True)  # 在线网络选
    next_q = target_values.gather(1, next_actions).squeeze(1)        # 目标网络评
else:
    next_q = target_values.max(dim=1).values
```

### 测试

用两个固定的 Q 网络：

- 在线网络在动作 0 上最大；
- 目标网络在动作 1 上最大，且动作 1 的值更高。

普通 max 会选目标网络的 1；Double 会选在线网络的 0，再用目标网络取动作 0 的值。
两者结果不同，才能证明实现正确。

### 实验

```powershell
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 `
    --bootstrap-truncated --use-target-network --double-dqn `
    --output-dir runs\stage2_d_double_seed0
```

---

## 6. 修正 4：Huber + 梯度裁剪（P1）

### 为什么

MSE 对大 TD error 很敏感。奖励是 +10/-10，早期 Q 值尺度可能很大，一个异常样本就能
主导梯度。Huber（`SmoothL1Loss`）在大误差时线性、小误差时平方，更稳。

梯度裁剪防止一次更新把参数推得太远。

### 建议实现

`DQNConfig` 加：

```python
huber: bool = False
grad_clip: float | None = None
```

`__init__`：

```python
self.criterion = nn.SmoothL1Loss() if self.config.huber else nn.MSELoss()
```

`train_step`：

```python
loss.backward()
if self.config.grad_clip is not None:
    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.grad_clip)
self.optimizer.step()
```

### 实验

```powershell
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 `
    --bootstrap-truncated --use-target-network --double-dqn `
    --huber --grad-clip 10 `
    --output-dir runs\stage2_e_huber_seed0
```

> 注意：Huber 会改变 loss 的数值尺度，不能直接和 MSE 的 loss 比大小；
> 要比的是评估分数和稳定性。

---

## 7. 修正 5：epsilon 调度（P1）

Stage 1 的 epsilon 在 80 局后归零。对 500 局的训练来说，这可能太早：

- 前 80 局还在学基本动作；
- 后面 420 局完全没有探索，容易卡在局部策略。

### 先不改代码，只改参数

```powershell
# 保留 5% 探索，150 局衰减
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 `
    --bootstrap-truncated --use-target-network --double-dqn --huber --grad-clip 10 `
    --epsilon-end 0.05 --epsilon-decay-games 150 `
    --output-dir runs\stage2_f_epsilon_seed0
```

### 要观察什么

- 训练 score 和 greedy eval 的差距是否缩小？
- 后期是否还在探索新的食物路径？
- 探索太高会让训练 score 变低，但 greedy eval 可能更好；别混淆。

---

## 8. 可选：标准 replay 更新（P2）

Stage 1 是“每步单样本更新 + 每局 batch 更新”，这是参考项目的非标准做法。
标准 DQN 是每一步从 replay 采样一个 minibatch 更新。

### 建议的实验设计

不要直接删掉 short memory。先加一个训练循环选项：

- `TrainConfig.replay_update_every: int = 0`
- 当 `short_memory=False` 且 `replay_update_every>0` 时，每 N 步调用
  `agent.train_long_memory()`；
- 比较：
  - A：Stage 1 原样（short + 每局 long）
  - B：只用 replay minibatch 每步更新
  - C：只用 replay minibatch 每 4 步更新

### 可能的结果

- 稀疏奖励下，去掉 short memory 可能让早期学习更慢；
- 但长期看，replay minibatch 更稳定、样本效率更高；
- 这是一个“工程/样本效率”实验，不是正确性修正。

---

## 9. 建议的消融顺序

| 版本 | 改动                       | 目的     |
| ---- | -------------------------- | -------- |
| A    | Stage 1 基线               | 对照     |
| B    | `bootstrap_truncated=True` | 正确性   |
| C    | B + 目标网络               | 稳定性   |
| D    | C + Double DQN             | 降低高估 |
| E    | D + Huber + 梯度裁剪       | 鲁棒性   |
| F    | E + epsilon 下限/更慢衰减  | 探索     |
| G    | F + replay 更新（可选）    | 样本效率 |

每个版本跑 500 局、seed=0；如果时间允许，再跑 seed=1/2。
不要在同一版里同时改两个东西。

### 消融表模板

| 版本       | 训练种子 | eval mean | median | max | std | self | wall | timeout | 训练耗时 |
| ---------- | -------: | --------: | -----: | --: | --: | ---: | ---: | ------: | -------: |
| A 基线     |        0 |           |        |     |     |      |      |         |          |
| B trunc    |        0 |           |        |     |     |      |      |         |          |
| C +target  |        0 |           |        |     |     |      |      |         |          |
| D +double  |        0 |           |        |     |     |      |      |         |          |
| E +huber   |        0 |           |        |     |     |      |      |         |          |
| F +epsilon |        0 |           |        |     |     |      |      |         |          |

> 表里填 100 局 greedy eval 的结果，不是训练时的 mean100。

---

## 10. 建议增加的诊断指标

Stage 1 只记录了 loss 和分数。Stage 2 建议加：

- **Q mean / Q max**：在每局初始观察上算一次，观察 Q 值是否爆炸/坍缩；
- **timeout rate**：判断 agent 是否在“安全绕圈”；
- **score per step**：区分“活得久”和“会找食物”；
- **eval 的 self/wall 比例**：后期主要死因；
- **target sync 次数**：确认目标网络真的在更新。

这些不需要复杂实现，加到 `train.csv` 即可。

---

## 11. 预期与陷阱

### 预期

- `bootstrap_truncated` 是正确性修正，不保证提分；
- 目标网络通常让训练更稳，但不一定立刻提分；
- Double DQN 主要降低高估，分数提升可能很小；
- 在 20×20 上，**观察（距离/身体形状）可能比这些算法修正更重要**；
- 后期主要死因是 self collision，目标网络解决不了“看不见身体”的问题。

### 陷阱

- 同时开多个开关，无法归因；
- 用训练 score 代替 greedy eval；
- 只跑一个种子，把运气当改进；
- loss 变小但评估变差：Huber/MSE 的 loss 尺度不同，不能直接比；
- 目标网络同步频率没记录，无法复现；
- 在评估种子上调参。

---

## 12. 自测题

<details>
<summary>1. 为什么 truncation 应该 bootstrap，而 termination 不应该？</summary>

termination 是真正的终止状态，之后没有未来，所以 target = r。
truncation 只是时间限制导致的中断，状态本身还可以继续，未来价值仍然存在，
所以 target = r + γ max Q_target(s')。
</details>

<details>
<summary>2. 目标网络为什么能缓解“追自己尾巴”？</summary>

target 用一套延迟更新的参数 θ⁻，在一段时间内保持静止。在线网络在两次同步之间
追的是一个固定的目标，而不是每一步都跟着自己变。
</details>

<details>
<summary>3. Double DQN 和普通 DQN 的区别是什么？</summary>

普通 DQN 用同一个网络既选 max 动作又评估它，容易高估。
Double DQN 用在线网络选动作、目标网络评估该动作，把选择和评估解耦。
</details>

<details>
<summary>4. 为什么 Huber 的 loss 不能和 MSE 的 loss 直接比大小？</summary>

它们的数值尺度不同：MSE 对大误差平方，Huber 在大误差时近似线性。
loss 的绝对值没有可比性，要比评估指标和训练稳定性。
</details>

<details>
<summary>5. 如果 Stage 2 的算法修正只带来很小提升，说明什么？</summary>

可能瓶颈不在优化器/目标，而在观察（POMDP）、奖励设计或探索。
这时应该进入 Stage 3，而不是继续堆 DQN 技巧。
</details>

<details>
<summary>6. 为什么后期 self collision 变多？</summary>

蛇变长后，身体占据更多格子，11 维观察只检查相邻三格，看不到更远的身体。
策略缺少身体形状信息，容易把自己困住。这是观察工程的问题。
</details>

---

## 13. 命令速查

```powershell
# B：只开 truncation bootstrap
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 --bootstrap-truncated `
    --output-dir runs\stage2_b_trunc_seed0

# C：再加目标网络（需要先实现 --use-target-network）
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 500 `
    --bootstrap-truncated --use-target-network `
    --output-dir runs\stage2_c_target_seed0

# 评估
.\.venv\Scripts\python.exe scripts\evaluate.py --run-dir runs\stage2_b_trunc_seed0 --episodes 100

# 测试
.\.venv\Scripts\python.exe -m pytest
```

Stage 1 的完整结果见 [`logs/stage1-dqn-baseline.md`](logs/stage1-dqn-baseline.md)。
Stage 2 的实验记录建议放在 `teach/logs/stage2-*.md`。
