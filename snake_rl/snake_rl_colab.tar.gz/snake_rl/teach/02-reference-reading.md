# 02 · 参考项目逐文件阅读

参考项目：[patrickloeber/snake-ai-pytorch](https://github.com/patrickloeber/snake-ai-pytorch)（MIT License）。

这份文档的目标不是“解释它写得多好”，而是：

1. 看懂它的每个设计；
2. 分清哪些是**教学简化**，哪些是**会影响正确性的问题**；
3. 设计我们自己的 Stage 1 复刻和 Stage 2 消融。

> 我们不会把它的代码直接搬进项目。我们会重新实现，并保留一个可对比的基线。

---

## 0. 文件地图

| 文件                  | 作用               | 关键内容                                             |
| --------------------- | ------------------ | ---------------------------------------------------- |
| `game.py`             | 游戏 + Pygame 渲染 | `SnakeGameAI.play_step`、`_move`、`is_collision`     |
| `agent.py`            | 智能体 + 训练循环  | 11 维状态、epsilon-greedy、replay、short/long memory |
| `model.py`            | 网络 + 训练器      | `Linear_QNet`、`QTrainer.train_step`                 |
| `helper.py`           | 画图               | matplotlib + IPython display                         |
| `snake_game_human.py` | 人类试玩           | 不在训练路径上                                       |
| `arial.ttf`           | 字体               | 渲染用                                               |

项目没有 `requirements.txt`，依赖需要自己装：`pygame`、`numpy`、`torch`、`matplotlib`、`ipython`。

---

## 1. `game.py`

### 1.1 状态与初始化

```python
self.head = Point(self.w/2, self.h/2)
self.snake = [self.head,
              Point(self.head.x-BLOCK_SIZE, self.head.y),
              Point(self.head.x-(2*BLOCK_SIZE), self.head.y)]
```

- 棋盘 640×480，格子 20 px，所以是 32×24 格；
- 初始蛇长 3，朝右；
- 坐标是**像素浮点数**（`w/2 = 320.0`），食物是整数像素。比较时 `320.0 == 320`，
  能跑，但不是最干净的表示。

### 1.2 `play_step` 的顺序

```python
self.frame_iteration += 1
# 处理 pygame 事件
self._move(action)
self.snake.insert(0, self.head)

if self.is_collision() or self.frame_iteration > 100*len(self.snake):
    game_over = True
    reward = -10
    return reward, game_over, self.score

if self.head == self.food:
    self.score += 1
    reward = 10
    self._place_food()
else:
    self.snake.pop()

self._update_ui()
self.clock.tick(SPEED)
return reward, game_over, self.score
```

值得注意：

1. **先移动、插入头，再检查碰撞**。撞死时，蛇头已经插入 `snake`，可能越界或与身体重叠。
   这就是为什么参考项目的死亡状态不一定是合法的棋盘状态。
2. **超时检查在吃食物之前**。如果这一步刚好走到食物上，但 `frame_iteration` 超限，
   会先判定超时，吃不到食物。
3. **`frame_iteration` 是整局总步数**，吃食物不重置。一条活了很久的蛇可能在吃完食物后
   很快被截断。
4. **每步都 `_update_ui()` + `clock.tick(SPEED)`**。训练被锁在 40 步/秒。

### 1.3 `_move`：相对动作

```python
clock_wise = [Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP]
idx = clock_wise.index(self.direction)

if np.array_equal(action, [1, 0, 0]):
    new_dir = clock_wise[idx]           # 直行
elif np.array_equal(action, [0, 1, 0]):
    new_dir = clock_wise[(idx + 1) % 4] # 右转
else:
    new_dir = clock_wise[(idx - 1) % 4] # 左转
```

这就是我们沿用的相对动作。它天然排除 180° 掉头。我们用整数 `0/1/2` 代替 one-hot，
语义相同，少一层 `np.array_equal`。

### 1.4 `is_collision`：尾巴语义

```python
if pt in self.snake[1:]:
    return True
```

它检查的是 `snake[1:]`，**包含尾巴**。如果蛇头下一步走进当前尾巴的格子，而这一步不吃食物，
尾巴其实会腾出来，所以严格来说不算撞。参考项目偏保守，会把这个动作判死。

我们的环境在非进食时用 `snake[:-1]`，允许走进即将腾出的尾巴。

### 1.5 与 Pygame 的耦合

`game.py` 同时负责：

- 游戏规则；
- Pygame 窗口、字体、事件；
- 帧率控制；
- 渲染。

这导致训练无法 headless，也无法方便地并行/测试。我们的 Stage 0 把逻辑和渲染拆开了。

### 阅读问题

- 如果 `action` 传入 `[0,0,0]`，会发生什么？
- `frame_iteration` 为什么不在吃到食物时重置？
- 撞死时 `snake` 里是否可能有越界坐标？这对渲染和测试有什么影响？
- `clock.tick(SPEED)` 对训练速度的影响有多大？估算一下 500 局、每局 100 步需要多久。

---

## 2. `agent.py`

### 2.1 11 维状态

```python
state = [
    # 正前方是否危险
    # 右方是否危险
    # 左方是否危险
    # 当前朝向 one-hot（左/右/上/下）
    # 食物在头的左/右/上/下
]
return np.array(state, dtype=int)
```

“右方/左方”是相对于当前朝向的，不是屏幕的左右。具体映射见
[01-mdp-snake.md](01-mdp-snake.md) 第 2 节。

### 2.2 epsilon-greedy

```python
self.epsilon = 80 - self.n_games
if random.randint(0, 200) < self.epsilon:
    move = random.randint(0, 2)
else:
    move = torch.argmax(self.model(state0)).item()
```

`randint(0, 200)` 包含 0 和 200，一共 201 个值。所以：

| 局数 | epsilon |            随机动作概率 |
| ---: | ------: | ----------------------: |
|    0 |      80 | $80/201 \approx 39.8\%$ |
|   40 |      40 | $40/201 \approx 19.9\%$ |
|   79 |       1 |   $1/201 \approx 0.5\%$ |
|   80 |       0 |                      0% |
|  >80 |    负数 |                      0% |

问题：**80 局后完全没有探索**。如果策略陷入局部最优（例如一直绕圈），它没有机会出来。
而且这个调度是硬编码的，和训练长度、棋盘大小无关。

### 2.3 经验回放

```python
self.memory = deque(maxlen=MAX_MEMORY)  # 100_000
...
def remember(self, state, action, reward, next_state, done):
    self.memory.append((state, action, reward, next_state, done))
```

存的是 `done`，不是分开的 `terminated/truncated`。这会影响超时的 bootstrap。

### 2.4 short memory / long memory

```python
# 每步
agent.train_short_memory(state_old, final_move, reward, state_new, done)

# 每局结束
agent.train_long_memory()
```

- `train_short_memory`：用**单个** transition 做一次梯度更新。连续样本高度相关，
  且每步都更新，容易过拟合最近的经验。
- `train_long_memory`：每局结束从 replay 里采样一个 batch（最多 1000）更新一次。

这不是标准 DQN 的“每步从 replay 采样一个 minibatch 更新”。它把“在线单样本更新”和
“回合末 batch 更新”混在一起。Stage 1 先复刻这个行为，Stage 2 再比较标准做法。

### 2.5 训练循环

```python
while True:
    state_old = agent.get_state(game)
    final_move = agent.get_action(state_old)
    reward, done, score = game.play_step(final_move)
    state_new = agent.get_state(game)

    agent.train_short_memory(state_old, final_move, reward, state_new, done)
    agent.remember(state_old, final_move, reward, state_new, done)

    if done:
        game.reset()
        agent.n_games += 1
        agent.train_long_memory()
        if score > record:
            record = score
            agent.model.save()
        print(...)
        plot(...)
```

问题：

- 没有评估阶段，训练时的 epsilon-greedy 表现就是唯一指标；
- 没有固定种子；
- 每局都画图，慢且依赖 IPython；
- `while True` 没有停止条件；
- `model.save()` 只保存 `state_dict`，没有 optimizer、配置、局数；
- 没有 load 方法。

### 阅读问题

- 为什么 `epsilon = 80 - n_games` 不是“epsilon 从 80 衰减到 0”这么简单？
- `train_short_memory` 每步更新有什么好处和坏处？
- 如果 `done=True` 是因为超时而不是死亡，target 应该怎么变？
- 这个循环里哪些随机性没有固定种子？

---

## 3. `model.py`

### 3.1 网络

```python
class Linear_QNet(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        self.linear1 = nn.Linear(input_size, hidden_size)
        self.linear2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = F.relu(self.linear1(x))
        x = self.linear2(x)
        return x
```

- 输入 11，隐藏 256，输出 3；
- 每个输出对应一个相对动作的 Q 值；
- 没有输出层激活（Q 值可正可负）。

### 3.2 `QTrainer.train_step`

核心：

```python
pred = self.model(state)
target = pred.clone()

for idx in range(len(done)):
    Q_new = reward[idx]
    if not done[idx]:
        Q_new = reward[idx] + self.gamma * torch.max(self.model(next_state[idx]))
    target[idx][torch.argmax(action[idx]).item()] = Q_new

loss = self.criterion(target, pred)
loss.backward()
self.optimizer.step()
```

逐点拆解：

1. **`pred`**：在线网络对当前 batch 所有动作的 Q 值，形状 `(B, 3)`。
2. **`target = pred.clone()`**：先复制一份预测作为 target 的容器。
3. 对每个样本，只覆盖**实际执行动作**对应的那一项：
   - `Q_new = r`，如果终止；
   - 否则 `Q_new = r + γ max_a Q_online(s', a)`。
4. 其余动作的 target 保持为原来的预测值。因为 loss 是 MSE，这些项的误差为 0，
   等价于只对选中动作做回归。
5. `loss.backward()` + `optimizer.step()`。

这里有几个值得注意的点：

- **没有目标网络**：`max(self.model(next_state[idx]))` 用的就是正在训练的网络。
  这就是你在笔记里质疑的“自己追自己”。DQN 用目标网络缓解。
- **没有 Double DQN**：`max` 直接在在线网络上取，容易高估。
- **没有 detach**：`target = pred.clone()` 仍然连着计算图。虽然非选中动作的误差为 0，
  但这种写法会保留不必要的图，也不是标准写法。更清晰的是
  `target = pred.detach().clone()`，或者用 `gather` 只取选中动作。
- **MSE**：对大 TD error 很敏感，异常值会主导梯度。Huber 更稳。
- **`done` 混用**：终止和截断都让 target 变成 `r`，超时被错误地当成死亡。
- **in-place 赋值**：`target[idx][...] = Q_new` 在 autograd 图里做原地修改；
  在参考项目的用法下能跑，但不是推荐写法。

### 3.3 保存

```python
def save(self, file_name='model.pth'):
    ...
    torch.save(self.state_dict(), file_name)
```

只有权重。没有 `load`，没有 optimizer state，没有配置。评估时需要自己重建网络结构，
很容易出现“结构对不上”的问题。

### 阅读问题

- 如果 batch 里 `done=True` 的样本，`Q_new` 是什么？
- 为什么 `target` 只覆盖选中动作，而不是覆盖所有动作？
- 如果把 `pred.clone()` 改成 `pred.detach().clone()`，训练会有什么不同？
- 在线网络同时算 target 会带来什么不稳定？

---

## 4. `helper.py`

```python
plt.ion()
def plot(scores, mean_scores):
    display.clear_output(wait=True)
    display.display(plt.gcf())
    plt.clf()
    ...
    plt.show(block=False)
    plt.pause(.1)
```

- 依赖 IPython 的 `display`；
- 每局都调用，`plt.pause(.1)` 至少 0.1 秒，500 局就是 50 秒；
- 在纯终端/服务器上可能行为不一致；
- 更好的做法：训练时写 CSV/TensorBoard，训练结束后再画图。

---

## 5. 问题清单

按“对结果的影响”排序，而不是按代码好不好看。

### P0：会影响正确性

| 问题                                | 影响                                   |
| ----------------------------------- | -------------------------------------- |
| 超时被当成终止，target 不 bootstrap | 低估接近超时的状态，可能学会“快点结束” |
| 没有目标网络                        | target 随在线网络快速移动，训练不稳定  |
| 没有独立评估                        | 无法区分“真学会了”和“epsilon 恰好低”   |
| `frame_iteration` 不随吃食物重置    | 长 episode 可能在刚吃完后被无端截断    |
| 没有固定种子                        | 实验不可复现，无法做消融               |

### P1：影响稳定性和样本效率

| 问题                  | 影响                     |
| --------------------- | ------------------------ |
| 没有 Double DQN       | Q 值高估                 |
| MSE                   | 对大误差敏感             |
| epsilon 80 局后归零   | 后期没有探索，容易卡住   |
| 每步单样本更新        | 相关性高，样本效率低     |
| 没有梯度裁剪          | 大 TD error 可能导致突变 |
| replay 使用方式不标准 | 难以和标准 DQN 对比      |

### P2：工程/实验卫生

| 问题                | 影响                              |
| ------------------- | --------------------------------- |
| 训练和 Pygame 耦合  | 训练被 40 FPS 锁死，无法 headless |
| 每局画图            | 慢，依赖 IPython                  |
| checkpoint 只有权重 | 无法恢复训练                      |
| 食物递归放置        | 棋盘满时可能无限递归              |
| 像素浮点坐标        | 不必要，容易混淆                  |
| 没有测试            | 规则改动后无法快速验证            |

### P3：上限/研究性

| 问题                | 影响               |
| ------------------- | ------------------ |
| 11 维观察是部分观察 | 策略上限受限       |
| 没有距离/身体形状   | 容易绕圈、自撞     |
| 没有 CNN/网格观察   | 无法利用空间结构   |
| 没有奖励塑形        | 早期学习慢         |
| 没有 action mask    | 会选立即致死的动作 |
| 没有多智能体        | 不涉及非平稳性     |

---

## 6. Stage 1 复刻计划

**目标**：在**不改算法**的前提下，把它跑得更快、更可观测。

保留：

- 11 维观察；
- 2 层 MLP（11→256→3）；
- 经验回放（容量 100k）；
- epsilon-greedy；
- 每步 short memory + 每局 long memory；
- 在线网络算 target（先不加目标网络）；
- 奖励 +10 / -10 / 0；
- gamma = 0.9。

改掉（仅限工程）：

- 纯逻辑环境 + headless 训练；
- 固定种子；
- CSV 日志（score、mean100、loss、epsilon、steps、死因）；
- 独立 greedy 评估；
- checkpoint 保存配置和 optimizer state；
- 不再每局画图。

**先不要修**：

- 目标网络；
- Double DQN；
- Huber；
- 终止/截断区分；
- 奖励塑形；
- 观察工程。

否则你无法回答“Stage 2 的改进到底来自哪里”。

---

## 7. 阅读练习

<details>
<summary>1. 追踪一步：头 (320,240)，朝右，动作 [0,1,0]，新头在哪？</summary>

`clock_wise = [RIGHT, DOWN, LEFT, UP]`，当前 index=0，右转后 index=1，方向 DOWN。
新头 = (320, 260)。然后 `snake.insert(0, head)`，长度变为 4；如果没吃食物，再 `pop()` 回 3。
</details>

<details>
<summary>2. epsilon 在 n_games=0、40、80 时的随机动作概率？</summary>

`randint(0,200)` 有 201 个值，条件是 `< epsilon`：

- n_games=0：80/201 ≈ 39.8%
- n_games=40：40/201 ≈ 19.9%
- n_games=80：0%

</details>

<details>
<summary>3. 为什么 target 只覆盖选中动作？</summary>

网络对每个动作输出一个 Q 值。一次 transition 只告诉我们“在 s 做 a 得到了 r 和 s'”，
所以只有 `Q(s,a)` 有新的回归目标。其他动作没有这次的数据，保持原预测即可。
实现上用 `pred.detach().clone()` 再覆盖选中项，或用 `gather` 只取选中动作的 Q。
</details>

<details>
<summary>4. `done=True` 时 target 是什么？如果 done 是超时，这样写有什么问题？</summary>

`Q_new = r`。如果 `done` 是死亡，这是对的；如果是超时，未来仍然存在，
应该用 `r + γ max Q_target(s')`。参考项目没有区分，所以超时被当成死亡。
</details>

<details>
<summary>5. 每步 `train_short_memory` 的问题是什么？</summary>

单个 transition 的梯度噪声大，连续样本高度相关；每步更新会让网络过度追随最近的经验，
也可能覆盖 replay batch 的学习效果。标准 DQN 是每步从 replay 采样一个 minibatch 更新。
</details>

<details>
<summary>6. 为什么 `clock.tick(SPEED)` 是训练瓶颈？</summary>

它让循环最多 40 步/秒。500 局 × 100 步 = 50,000 步，至少 1250 秒（约 21 分钟）。
headless 环境每秒可以跑几千步，差距两个数量级。
</details>

<details>
<summary>7. 你会先改哪一个？为什么？</summary>

没有标准答案。一个合理的顺序是：先 headless + 日志 + 固定种子（让实验可测），
再修终止/截断（正确性），再加目标网络（稳定性），最后做 Double DQN/Huber（进一步改进）。
关键不是顺序本身，而是每次只改一个，并记录假设和结果。
</details>

---

## 8. 一句话总结

> 参考项目是一个很好的“最小可运行 DQN 教学实现”，它把主要零件都摆出来了；
> 但它把训练、渲染、评估、随机性、终止语义混在一起，不适合直接作为实验基线。
> Stage 1 先复刻它的算法，Stage 2 再逐项修正。

Stage 1 已经按上面的计划实现：代码见 `snake_rl/agents/dqn.py`，
讲解见 [04-stage1-dqn-baseline.md](04-stage1-dqn-baseline.md)。

下一份：[03-stage0-environment.md](03-stage0-environment.md)。
