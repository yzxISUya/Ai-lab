# 04 · Stage 1：DQN 基线

Stage 1 的目标不是“把蛇训到多强”，而是先得到一个**能跑、能评估、能复现**的 DQN 基线。
它刻意保留参考项目的算法结构，方便 Stage 2 一项一项地改、一项一项地量。

---

## 1. 这一阶段做了什么

代码：

```
snake_rl/env/observations.py     # 11 维观察
snake_rl/models/qnet.py          # 11 -> 256 -> 3 的 MLP
snake_rl/agents/dqn.py           # Transition / Batch / ReplayBuffer / DQNAgent
snake_rl/training/train_dqn.py   # headless 训练循环、CSV 日志、checkpoint
snake_rl/training/evaluate.py    # greedy 评估
snake_rl/training/logging.py     # CSV/JSON 小工具
scripts/train_dqn.py             # 训练入口
scripts/evaluate.py              # 评估入口
scripts/plot_training.py         # 画曲线
tests/test_observations.py       # 观察测试
tests/test_dqn.py                # DQN 组件测试
```

算法上**保留**参考项目的行为：

- 11 维观察；
- 2 层 MLP（11→256→3）；
- 经验回放，容量 100k；
- epsilon-greedy；
- 每步用单个 transition 更新一次（short memory）；
- 每局结束从 replay 采样一个 batch 更新（long memory）；
- **没有目标网络**：target 用在线网络算；
- MSE loss；
- 默认把 truncation 当成 termination（`bootstrap_truncated=False`）。

工程上**改进**了：

- 纯逻辑环境 + headless 训练，不受 pygame 帧率限制；
- 固定环境/动作/replay/网络初始化种子；
- 独立 greedy 评估，训练和评估用不同种子；
- CSV 日志、checkpoint、可复现命令；
- target 计算用 `torch.no_grad()`，不让标签反传；
- replay 同时保存 `terminated` 和 `truncated`，Stage 2 可以不改数据格式就切换语义。

---

## 2. 11 维观察

`snake_rl/env/observations.py::observe(env)`：

|  位 | 名字              | 含义                  |
| --: | ----------------- | --------------------- |
|   0 | `danger_straight` | 正前方是否撞墙/撞身体 |
|   1 | `danger_right`    | 右转方向是否危险      |
|   2 | `danger_left`     | 左转方向是否危险      |
|   3 | `dir_left`        | 当前朝左              |
|   4 | `dir_right`       | 当前朝右              |
|   5 | `dir_up`          | 当前朝上              |
|   6 | `dir_down`        | 当前朝下              |
|   7 | `food_left`       | 食物在头的左边        |
|   8 | `food_right`      | 食物在头的右边        |
|   9 | `food_up`         | 食物在头的上边        |
|  10 | `food_down`       | 食物在头的下边        |

位顺序与参考项目的 `get_state()` 一致。

### 一个保守语义

`observe(env)` 默认 `ignore_tail=False`：

- 参考项目的 `is_collision` 检查 `snake[1:]`，包含尾巴；
- 所以“下一步走进当前尾巴”在 11 维观察里会被标成危险；
- 但我们的环境实际允许这一步（尾巴会腾出）。

这是 Stage 1 为了对齐参考项目故意保留的不一致。Stage 2/3 可以统一它，
并观察它是否影响学习。

### 为什么它不够

11 维观察没有距离、没有身体形状、没有更远的障碍。它对应的是 POMDP。
Stage 1 的评估如果出现“绕圈/不找食物”，不一定是 DQN 的问题，也可能是观察不够。
Stage 3 才处理这个。

---

## 3. Q 网络

`snake_rl/models/qnet.py`：

```python
class QNet(nn.Module):
    def __init__(self, input_size=11, hidden_size=256, output_size=3):
        self.linear1 = nn.Linear(input_size, hidden_size)
        self.linear2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        return self.linear2(F.relu(self.linear1(x)))
```

张量形状：

| 对象                  | 形状       |
| --------------------- | ---------- |
| 单条观察              | `(11,)`    |
| 单条 batch            | `(1, 11)`  |
| replay batch          | `(B, 11)`  |
| `linear1` 输出        | `(B, 256)` |
| `linear2` 输出 / Q 值 | `(B, 3)`   |

输出层没有激活，因为 Q 值可以为负。

---

## 4. 经验回放

`snake_rl/agents/dqn.py`：

```python
class Transition(NamedTuple):
    obs: np.ndarray
    action: int
    reward: float
    next_obs: np.ndarray
    terminated: bool
    truncated: bool
```

为什么同时存 `terminated` 和 `truncated`？

- Stage 1 默认 `done = terminated | truncated`，复刻参考项目；
- Stage 2 只要把 `bootstrap_truncated=True`，就能变成“只有终止才砍未来”；
- 不需要重新采集数据，也不需要在 replay 里做格式迁移。

`ReplayBuffer.sample()` 用独立的 `random.Random(seed)` 从 deque 里无放回采样；
不足 `batch_size` 时返回全部。无放回采样在 100k 容量、1000 batch 下影响可以忽略，
但严格来说和“有放回”不同；Stage 2 可以把它作为一个实验变量。

---

## 5. TD target

这是 DQN 的核心。`DQNAgent.train_step(batch)`：

```python
pred = self.model(obs)                                  # (B, 3)
pred_q = pred.gather(1, actions.unsqueeze(1)).squeeze(1)  # (B,)
target = self.compute_targets(batch)                    # (B,)
loss = self.criterion(pred_q, target)                   # MSE
```

`compute_targets`：

```python
with torch.no_grad():
    next_q = self.model(next_obs).max(dim=1).values     # Stage 1：在线网络
    done = terminated if bootstrap_truncated else (terminated | truncated)
    target = rewards + gamma * next_q * (~done).float()
```

逐项解释：

- `pred.gather(...)`：只取**实际执行动作**的 Q 值。一次 transition 只给这个动作提供了新目标，
  其他两个动作没有数据，不需要回归。
- `max(dim=1).values`：Q-learning 的 max 目标。
- `(~done).float()`：终止/截断的样本不再 bootstrap，target 退化为 `r`。
- `torch.no_grad()`：target 是标签，不应该反传。参考项目用 `pred.clone()` 的写法可能让
  target 也带梯度；我们不复刻这个 bug。

### Stage 1 的偏差

`bootstrap_truncated=False` 意味着超时也被当成终止：

$$
y = r \quad \text{（超时也这样）}
$$

正确的做法应该是超时仍然 bootstrap：

$$
y = r + \gamma \max_{a'} Q_{\theta^-}(s',a')
$$

这就是 Stage 2 的第一个正确性修正。

---

## 6. epsilon 调度

`DQNAgent.epsilon`：

```python
progress = min(1.0, n_games / epsilon_decay_games)
epsilon = epsilon_start + progress * (epsilon_end - epsilon_start)
```

默认 `0.4 -> 0.0`，持续 80 局。

参考项目的写法是：

```python
epsilon = 80 - n_games
if random.randint(0, 200) < epsilon: random_action()
```

它在第 0 局约为 $80/201 \approx 39.8\%$，第 80 局为 0。我们用线性概率复刻了同样
的端点，但实现更直观。差异在于随机数序列，不在探索强度上。

---

## 7. 训练循环

`snake_rl/training/train_dqn.py::run_training`：

```python
for episode in range(1, episodes + 1):
    env.reset(seed=seed + episode)
    obs = observe(env)

    while not env.done:
        action = agent.get_action(obs)
        outcome = env.step(action)
        next_obs = observe(env)

        transition = Transition(obs, action, outcome.reward, next_obs,
                                outcome.terminated, outcome.truncated)

        if short_memory:
            agent.train_short_memory(transition)   # 每步单样本
        agent.remember(transition)

        obs = next_obs

    agent.end_episode()          # n_games += 1，epsilon 衰减
    agent.train_long_memory()    # 每局 replay batch
```

几个细节：

- 环境每局用 `seed + episode` 重置，食物序列可复现；
- 动作探索、replay 采样各有独立的 RNG；
- `n_games` 在局末增加，所以第 1 局用的是 `epsilon=0.4`；
- `short_memory` 是参考项目的非标准做法：每步用一条经验更新，连续样本高度相关；
- `long_memory` 每局采样 batch=1000，但 replay 容量只有 100k，早期 replay 里样本很少。

Stage 2 可以比较：

- 保留 short memory vs 只用 replay minibatch；
- 每步更新 vs 每 N 步更新；
- batch size / replay ratio。

---

## 8. 评估

`snake_rl/training/evaluate.py::evaluate_agent`：

- greedy（epsilon=0）；
- 固定评估种子，默认 `10_000 + i`；
- 默认无渲染；
- 训练中每 50 局评估 20 局，训练结束评估 100 局（种子 20_000 起）；
- 指标：mean/median/max/min/std、平均步数、score/step、结束方式分布。

为什么不能看训练时的 score？

- 训练时是 epsilon-greedy，带探索；
- epsilon 在变，早期随机动作多，晚期少；
- 训练 score 高可能只是“探索时碰巧吃到”，不代表 greedy 策略好。

---

## 9. 实验

> 本节保留迁移前的原始记录：命令是在 Windows + pip 环境下跑的，耗时也是那台机器
> 的数字。现在请用第 15 节的 uv 命令；脚本参数和语义不变。

### 9.1 50 局开发实验

命令：

```powershell
.\.venv\Scripts\python.exe scripts\train_dqn.py --episodes 50 --eval-every 25 `
    --eval-episodes 20 --final-eval-episodes 20 --checkpoint-every 25 `
    --log-every 5 --output-dir runs\stage1_dev
```

实际结果（20×20，CPU）：

| episode | train score | mean100 | epsilon | greedy eval mean | eval 结束方式 |
| ------: | ----------: | ------: | ------: | ---------------: | ------------- |
|      10 |           1 |    0.20 |   0.355 |                — | —             |
|      25 |           1 |    0.52 |   0.280 |             0.00 | timeout 20    |
|      50 |           1 |    0.86 |   0.155 |             0.55 | timeout 20    |

最后 greedy 评估：

- mean 0.55，median 0.0，max 3，std 0.94；
- 平均步数 370.8；
- **20 局全部 timeout**；
- 训练 4744 步，29.2 秒（约 163 步/秒）。

这是一个**早期现象**：50 局时训练还没成形，greedy 策略只会绕到超时。
完整 500 局跑到 100 局时，greedy eval 已经到 25.20，说明 50 局太短，
不能用来判断“DQN 学不会”。

当时列出的可能原因（后来部分被证伪，需要 Stage 2 重新测）：

1. 没有目标网络，Q 值估计不稳定，greedy 动作不等于“会找食物”的动作；
2. 11 维观察没有距离，策略很难稳定地朝食物走；
3. epsilon 在 50 局时还有 0.155，训练 score 有一部分来自探索；
4. 超时和死亡都给 -10，agent 可能更倾向于“安全地绕圈”而不是冒险接近食物；
5. short memory 每步更新 + 每局 batch 更新，二者的相对权重没有调过。

完整训练表明，至少“学不会”这个判断是错的；真正的问题是**训练规模和评估局数都太小**。

### 9.2 500 局 baseline：最终结果

训练：**189,708 步，922.3 秒，约 205.7 步/秒**（约 15.4 分钟，CPU）。

最终 greedy 评估（100 局，seed=20_000 起）：

| 指标                        |             值 |
| --------------------------- | -------------: |
| mean                        |      **27.14** |
| median                      |           26.0 |
| max                         |             52 |
| min                         |              1 |
| std                         |          10.13 |
| mean steps                  |         405.44 |
| score/step                  |         0.0669 |
| wall / self / timeout / win | 5 / 95 / 0 / 0 |

独立复核（100 局，seed=10_000 起，重新加载 checkpoint）：mean 27.21、median 27.5、
max 61、std 11.88、self 99 / wall 1。两次评估几乎一致，说明 checkpoint 和评估流程稳定。

训练过程中每 50 局的 20 局 greedy eval：

| episode   |   50 |   100 |   150 |   200 |   250 |   300 |   350 |   400 |   450 |   500 |
| --------- | ---: | ----: | ----: | ----: | ----: | ----: | ----: | ----: | ----: | ----: |
| eval mean | 0.55 | 25.20 | 26.50 | 28.85 | 30.30 | 23.85 | 25.90 | 32.60 | 25.70 | 29.60 |

20 局评估的波动很大（23.85–32.60），最终 100 局的 27.14 更可靠。

![Stage 1 训练曲线](logs/stage1_curve.png)

曲线要点：

- 50–100 局之间出现跃升，之后 mean100 在 25–30 左右平台化；
- epsilon 第 80 局归零，但策略继续改善到约 175 局；
- self collision 成为主导死因（最终 95/100）；
- loss 在 3–5 左右波动，没有爆炸。

画图命令：

```powershell
.\.venv\Scripts\python.exe scripts\plot_training.py --run-dir runs\stage1_seed0
```

会得到 `runs/stage1_seed0/curve.png`。

---

## 10. 怎么读这条 baseline

不要只看“最高分”。至少看四组信息：

1. **训练 score 和 mean100**：是否在上升？是否只是 epsilon 带来的噪声？
2. **greedy eval**：是否也在上升？如果训练上升但 eval 不动，说明策略没有真正改进。
3. **结束方式**：早期多是 wall；如果后期 timeout 占比很高，说明 agent 在“安全地绕圈”。
4. **loss**：不需要单调下降；看是否爆炸、是否长期不降、是否和 Q 值尺度一起失控。

Stage 1 的结论：

> 在 11 维观察、无目标网络、MSE、epsilon 80 局衰减的设置下，500 局后
> greedy eval mean **27.14**（median 26、max 52、std 10.13），随机基线是 0.11；
> 主要失败模式是 self collision（95/100）；loss 稳定在 3–5，没有爆炸。
> 这组数字是 Stage 2 的对照点；平台化和 self collision 说明更大的杠杆可能在
> Stage 3 的观察工程，而不是继续堆 DQN 技巧。

不要把“训练 score 高”直接写成“DQN 学会了”。

---

## 11. 代码地图

| 想看什么     | 去哪里                                             |
| ------------ | -------------------------------------------------- |
| 观察怎么组装 | `snake_rl/env/observations.py::observe`            |
| 网络结构     | `snake_rl/models/qnet.py::QNet`                    |
| 经验结构     | `snake_rl/agents/dqn.py::Transition` / `Batch`     |
| replay       | `snake_rl/agents/dqn.py::ReplayBuffer`             |
| 动作选择     | `snake_rl/agents/dqn.py::DQNAgent.get_action`      |
| TD target    | `snake_rl/agents/dqn.py::DQNAgent.compute_targets` |
| 更新         | `snake_rl/agents/dqn.py::DQNAgent.train_step`      |
| 训练循环     | `snake_rl/training/train_dqn.py::run_training`     |
| 评估         | `snake_rl/training/evaluate.py::evaluate_agent`    |
| 日志         | `snake_rl/training/logging.py::CSVLogger`          |

---

## 12. 运行时流程：命令、文件与信息流

前面各节回答的是“每个组件在算什么”。这一节换一个视角，只回答四个问题：

1. 敲下命令之后，程序从哪里进入？
2. 依次经过哪些文件？
3. 每个文件**接收什么、负责什么、交出什么**？
4. 最后在磁盘上留下哪些文件，给谁用？

> 第 9 节保留的是当时在 Windows + pip 环境下的原始命令和实验记录；
> 本节按当前 uv 环境书写。`uv run` 会自动使用 `snake_rl/.venv`。

### 12.1 先看分层与依赖

整个包可以按角色分成这几层：

| 层          | 文件                           | 职责                                     | 明确不做什么             |
| ----------- | ------------------------------ | ---------------------------------------- | ------------------------ |
| 配置层      | `snake_rl/config.py`           | 参数定义与合法性校验                     | 不读文件、不建对象       |
| 环境层      | `snake_rl/env/snake_env.py`    | 游戏规则：转向、移动、碰撞、吃食物、超时 | 不知道神经网络的存在     |
| 观察层      | `snake_rl/env/observations.py` | 把完整状态压成 11 维特征                 | 不修改环境               |
| 模型层      | `snake_rl/models/qnet.py`      | 函数近似：11 → 256 → 3                   | 不知道动作、奖励、游戏   |
| 智能体层    | `snake_rl/agents/dqn.py`       | 选动作、存经验、算 TD target、更新参数   | 不组织训练循环、不写日志 |
| 训练/工具层 | `snake_rl/training/*.py`       | 循环、评估、CSV/JSON、checkpoint         | 不实现算法细节           |
| 入口层      | `scripts/*.py`                 | 解析参数、调用包里的 `main()`            | 不承载业务逻辑           |
| 可选渲染    | `snake_rl/env/renderer.py`     | 把 `SnakeState` 画到 pygame 窗口         | 不参与训练、不改变状态   |

静态依赖关系（箭头表示 `import`，从上往下）：

```
scripts/train_dqn.py
└── training/train_dqn.py
    ├── config.py
    ├── agents/dqn.py
    │   ├── config.py
    │   └── models/qnet.py
    ├── env/snake_env.py
    │   └── config.py
    ├── env/observations.py
    │   └── env/snake_env.py
    ├── training/evaluate.py
    │   ├── agents/dqn.py
    │   ├── env/snake_env.py
    │   └── env/observations.py
    └── training/logging.py

scripts/evaluate.py
├── agents/dqn.py
├── config.py
├── env/snake_env.py
├── training/evaluate.py
└── training/logging.py

scripts/random_agent.py → config.py, env/snake_env.py
scripts/play_human.py   → config.py, env/snake_env.py, env/renderer.py
scripts/plot_training.py → 只读 CSV；**不 import 任何 snake_rl 模块**
```

三条边界规则值得记住：

- **环境不依赖智能体**：`snake_env.py` 只 import `config.py`，所以环境可以单独测试、
  单独跑随机策略。
- **模型不依赖环境**：`qnet.py` 只认识张量，换一个任务只要改输入输出维度。
- **渲染是可选支线**：默认训练路径不 import pygame；只有 `--render` 或
  `play_human.py` 才加载 `renderer.py`。

`snake_rl/env/__init__.py`、`agents/__init__.py`、`models/__init__.py`、
`training/__init__.py` 只做 re-export，不包含逻辑。

---

### 12.2 训练：`scripts/train_dqn.py`

```bash
OMP_NUM_THREADS=4 uv run python scripts/train_dqn.py \
    --episodes 500 --output-dir runs/stage1_seed0
```

**启动阶段**

| 顺序 | 文件 / 函数                           | 接收             | 负责                                                            | 交出                                      |
| ---- | ------------------------------------- | ---------------- | --------------------------------------------------------------- | ----------------------------------------- |
| 1    | `uv run`                              | 命令文本         | 定位 `.venv`，必要时先同步依赖                                  | 一个使用项目环境的 Python 进程            |
| 2    | `scripts/train_dqn.py`                | CLI 参数（原样） | 只 import 并调用 `main()`                                       | 无；控制权交给包                          |
| 3    | `training/train_dqn.py::main`         | `sys.argv`       | `argparse` 解析，组装三个配置对象                               | `EnvConfig` / `DQNConfig` / `TrainConfig` |
| 4    | `config.py` 的三个 dataclass          | 标量参数         | `__post_init__` 校验（宽高、初始长度、lr、gamma、batch、局数…） | 校验通过的冻结配置                        |
| 5    | `training/train_dqn.py::run_training` | 三个配置         | 建目录、写配置、建环境/智能体/日志器，进入主循环                | 训练产物                                  |

**准备阶段（`run_training` 开头）**

| 对象           | 谁创建                                | 内部持有什么                                               |
| -------------- | ------------------------------------- | ---------------------------------------------------------- |
| 输出目录       | `run_training`                        | 先写 `config.json`（三份配置的 `asdict`）                  |
| 训练环境       | `SnakeEnv(env_config, seed)`          | 游戏状态 + 食物随机数流                                    |
| 评估环境       | `SnakeEnv(env_config, seed + 10_000)` | 独立的游戏状态；每局 `reset(seed)` 会覆盖构造时的种子      |
| 智能体         | `DQNAgent(dqn_config, device)`        | `QNet`、Adam、MSELoss、`ReplayBuffer`、动作 RNG、`n_games` |
| 日志器         | `CSVLogger` × 2                       | `train.csv`（12 列）与 `eval.csv`（13 列），每行立即 flush |
| 渲染器（可选） | `PygameRenderer`                      | 只在 `--render` 时 import；会拖慢采样                      |

**一局的执行顺序（单步信息流）**

```
SnakeEnv.reset(seed + episode)
   └─→ SnakeState
observe(env)                        # 只读 env.state / env.will_collide
   └─→ obs: (11,) float32
while not env.done:
    agent.get_action(obs)           # ε-greedy；QNet(1,11) → (1,3) → argmax
       └─→ action: int ∈ {0, 1, 2}
    env.step(action)                # 唯一修改游戏状态的地方
       └─→ StepOutcome(state, reward, terminated, truncated, info)
    observe(env)
       └─→ next_obs: (11,) float32
    Transition(obs, action, reward, next_obs, terminated, truncated)
       ├─→ agent.train_short_memory(t)    # 立即一次梯度更新（B=1）
       └─→ agent.remember(t)              # 存进 replay（容量 100k）
```

`train_short_memory` 内部展开成：

```
Batch(B=1)
  ├─ QNet(obs) ───────────────→ pred (B,3) ──gather(action)──→ pred_q (B,)
  └─ QNet(next_obs) [no_grad] → next_q (B,) ──max───────────→ target (B,)
loss = MSE(pred_q, target) → backward → optimizer.step() → float(loss)
```

**各文件在这一步里的边界**

| 文件                          | 接收           | 负责                           | 交出                   | 不负责           |
| ----------------------------- | -------------- | ------------------------------ | ---------------------- | ---------------- |
| `env/snake_env.py`            | `action: int`  | 转向、移动、碰撞、吃食物、超时 | `StepOutcome` + 新状态 | 不知道神经网络   |
| `env/observations.py`         | `env`（只读）  | 把状态压成 11 个 bit           | `(11,) float32`        | 不修改环境       |
| `models/qnet.py`              | `(B,11)` 张量  | 两层全连接                     | `(B,3)` Q 值           | 不知道动作、奖励 |
| `agents/dqn.py::get_action`   | `obs`          | ε 探索 + argmax                | `int`                  | 不更新参数       |
| `agents/dqn.py::train_step`   | `Batch`        | TD target、MSE、反传、优化     | `float` loss           | 不采集经验       |
| `agents/dqn.py::ReplayBuffer` | `Transition`   | 定长存储、无放回采样           | `Batch`                | 不做训练         |
| `training/logging.py`         | 行 dict / JSON | 写 CSV 并 flush、读写 JSON     | 磁盘文件               | 不计算任何指标   |

`StepOutcome.info` 里固定带 `score / steps / steps_since_food / snake_length`，
结束时再附加 `death_reason`、`timeout` 或 `win` 之一。

**局末**

| 顺序 | 调用                             | 接收              | 负责                                    | 交出                              |
| ---- | -------------------------------- | ----------------- | --------------------------------------- | --------------------------------- |
| 1    | `agent.epsilon`                  | `n_games`         | 线性调度                                | 这一局实际使用的 ε                |
| 2    | `agent.end_episode()`            | —                 | `n_games += 1`                          | 下一局的 ε                        |
| 3    | `agent.train_long_memory()`      | replay            | `sample(1000)` → `Batch` → `train_step` | `long_loss`；replay 为空时 `None` |
| 4    | `statistics.mean(scores_window)` | 最近 100 局 score | 平滑训练曲线                            | `mean100`                         |
| 5    | 结束方式判定                     | `last_info`       | win / timeout / wall / self             | 日志中的 `end=`                   |
| 6    | `CSVLogger.log`                  | 上述字段          | 写 `train.csv` 并 flush                 | 一行 CSV                          |
| 7    | `evaluate_agent`（每 50 局）     | agent、eval_env   | 20 局 greedy                            | `EvalResult` → `eval.csv`         |
| 8    | `agent.save`（每 50 局）         | —                 | 序列化                                  | `checkpoint.pt`                   |

注意顺序：日志里的 ε 是**这一局**用过的值，因为 `end_episode()` 在读完 ε 之后才调用。

`agent.save` 写出的内容（评估和续训都靠它）：

```python
{
    "model": state_dict,           # QNet 权重
    "optimizer": state_dict,       # Adam 状态
    "n_games": int,                # ε 调度位置
    "dqn_config": dict,            # 重建 DQNAgent 用
    "torch_rng_state": ...,        # 可复现
    "action_rng_state": ...,
    "replay_rng_state": ...,
    "cuda_rng_state": ...,         # 仅 CUDA 设备
}
```

**训练结束**

1. `evaluate_agent(seed=20_000)` 跑 100 局 → `final_eval.json`；
2. 再 `agent.save` 一次；
3. `summary.json`：总步数、耗时、steps/s、最终评估、三份配置；
4. `Ctrl-C` 中断会走 `except KeyboardInterrupt`，先存 checkpoint 再抛出。

**训练命令留下的文件**

| 产物              | 写入者          | 时机                   | 内容                                                          | 后续谁读                    |
| ----------------- | --------------- | ---------------------- | ------------------------------------------------------------- | --------------------------- |
| `config.json`     | `save_json`     | 开始                   | env / dqn / train 全部参数                                    | `scripts/evaluate.py`、人   |
| `train.csv`       | `CSVLogger`     | 每局                   | score、steps、mean100、ε、短/长 loss、结束方式、累计耗时      | `plot_training.py`          |
| `eval.csv`        | `CSVLogger`     | 每 `eval_every` 局     | 评估局数、均值/中位数/极值/标准差、步数、score/step、结束方式 | `plot_training.py`          |
| `checkpoint.pt`   | `DQNAgent.save` | 每 50 局 / 结束 / 中断 | 权重、优化器、配置、RNG                                       | `scripts/evaluate.py`、续训 |
| `final_eval.json` | `save_json`     | 结束                   | 100 局 greedy 评估                                            | 人                          |
| `summary.json`    | `save_json`     | 结束                   | 汇总指标与吞吐                                                | 人                          |

> `--render` 会在训练循环里额外调用 `renderer.draw()` / `tick()` / `should_quit()`；
> 它只消费 `StepOutcome.state`，不改变任何训练数据。

---

### 12.3 评估：`scripts/evaluate.py`

```bash
uv run python scripts/evaluate.py --run-dir runs/stage1_seed0 --episodes 100
```

| 顺序 | 文件 / 函数                         | 接收                   | 负责                                                                                 | 交出                  |
| ---- | ----------------------------------- | ---------------------- | ------------------------------------------------------------------------------------ | --------------------- |
| 1    | `scripts/evaluate.py::parse_args`   | CLI                    | 解析 `--run-dir`、`--episodes`、`--seed`、`--device`                                 | Namespace             |
| 2    | `training/logging.py::load_json`    | `config.json`          | 读出训练时的配置                                                                     | dict                  |
| 3    | `EnvConfig(**cfg["env"])`           | 环境部分               | 重建环境参数（会再跑一次校验）                                                       | `EnvConfig`           |
| 4    | `DQNAgent.load(checkpoint, device)` | `checkpoint.pt`        | `torch.load` → `DQNConfig(**dqn_config)` → 建 agent → 载权重 → 恢复 `n_games` 和 RNG | 可推理的 agent        |
| 5    | `SnakeEnv(env_config)`              | 配置                   | 建一个干净环境（此时还没有种子）                                                     | 环境                  |
| 6    | `evaluate_agent(...)`               | agent、env、局数、seed | 逐局 `reset(seed+i)`、`get_action(greedy=True)`、`step`、统计                        | `EvalResult`          |
| 7    | `format_eval` / `save_json`         | `EvalResult`           | 打印一行摘要，写 `eval.json`                                                         | 终端输出、`eval.json` |

三个容易忽略的点：

- 评估**不读 `config.json` 里的 DQN 配置**，只读 `env` 部分；网络结构来自
  checkpoint 里的 `dqn_config`。这样权重和结构永远配套。
- `greedy=True` 直接跳过 ε 分支，所以 checkpoint 里的 `n_games` 不影响评估动作。
- 评估**不更新参数、不写 `train.csv`**；`eval.json` 是唯一产物。

`EvalResult` 的字段：`episodes`、`mean_score`、`median_score`、`max_score`、
`min_score`、`std_score`、`mean_steps`、`score_per_step`、`endings`、`scores`。

`--render` 时才会 import `PygameRenderer`，评估循环里每步画一帧并检查关窗。

---

### 12.4 画曲线：`scripts/plot_training.py`

```bash
uv run python scripts/plot_training.py --run-dir runs/stage1_seed0
```

| 顺序 | 文件 / 函数                            | 接收            | 负责                                    | 交出                   |
| ---- | -------------------------------------- | --------------- | --------------------------------------- | ---------------------- |
| 1    | `scripts/plot_training.py::parse_args` | CLI             | 解析 `--run-dir` / `--output` / `--dpi` | Namespace              |
| 2    | `read_rows`                            | `train.csv`     | `csv.DictReader` → 每局一行             | `list[dict[str, str]]` |
| 3    | 同一函数                               | 可选 `eval.csv` | 取出评估 episode 与 mean                | 两条列表               |
| 4    | `matplotlib`（`Agg` 后端）             | 序列            | 画 2×2 子图：score / loss / ε / steps   | `Figure`               |
| 5    | `fig.savefig`                          | `Figure`        | 写文件                                  | `curve.png`            |

关键点：

- 这个脚本**不 import 任何 `snake_rl` 模块**，只消费 CSV——训练和画图完全解耦。
- `matplotlib.use("Agg")` 不需要显示器，适合 WSL / 服务器。
- 找不到 `train.csv` 直接 `SystemExit`；`eval.csv` 缺失时只画训练曲线。
- 空字符串和 `nan` 都会被转成 `NaN`，曲线自动断开；例如禁用 short memory 后，
  `short_loss` 列就是 `nan`。

---

### 12.5 测试：`uv run pytest`

```bash
uv run pytest          # 37 passed
uv run pytest -v       # 看每个用例名
```

| 顺序 | 参与者      | 接收                        | 负责                                              | 交出                                              |
| ---- | ----------- | --------------------------- | ------------------------------------------------- | ------------------------------------------------- |
| 1    | `uv run`    | 命令                        | 保证 `.venv` 与 `pyproject.toml` / `uv.lock` 一致 | 测试进程                                          |
| 2    | `pytest`    | `[tool.pytest.ini_options]` | 读 `testpaths=["tests"]`、`addopts="-q"`          | 收集范围                                          |
| 3    | 收集器      | `tests/` 三个文件           | 导入模块、收集 37 个用例                          | 用例列表                                          |
| 4    | 各测试函数  | 直接调用包里的类/函数       | 构造小局面、断言形状与数值                        | 通过 / 失败                                       |
| 5    | pytest 汇总 | 结果                        | 统计与报错                                        | 终端输出；只在根目录留下已忽略的 `.pytest_cache/` |

覆盖范围：

| 测试文件               | 覆盖的模块                        | 覆盖内容                                                                   | 用例数 |
| ---------------------- | --------------------------------- | -------------------------------------------------------------------------- | -----: |
| `test_snake_env.py`    | `config.py`、`env/snake_env.py`   | reset、相对动作、撞墙/撞自己、尾巴让位、吃食物、超时、可复现性、配置校验   |     15 |
| `test_observations.py` | `env/observations.py`             | 11 位顺序、三个危险位、四个食物位、`food=None`、尾巴保守语义               |      9 |
| `test_dqn.py`          | `agents/dqn.py`、`models/qnet.py` | 张量形状、replay 容量/可复现、ε 调度、TD target、参数更新、checkpoint 往返 |     13 |

**没有被测试覆盖的部分**：`training/train_dqn.py` 的训练循环、`training/logging.py`
的文件 IO、`env/renderer.py`、以及 `scripts/*` 的命令行。这些靠 smoke 训练
（`--episodes 5`）+ 人工看输出兜底。

测试里不需要 pygame 窗口，也不需要 GPU；`test_checkpoint_roundtrip` 用 pytest
内置的 `tmp_path`，不会污染 `runs/`。

---

### 12.6 随机基线：`scripts/random_agent.py`

```bash
uv run python scripts/random_agent.py --episodes 100
```

| 顺序 | 文件 / 函数                           | 接收            | 负责                                            | 交出                   |
| ---- | ------------------------------------- | --------------- | ----------------------------------------------- | ---------------------- |
| 1    | `scripts/random_agent.py::parse_args` | CLI             | 解析局数、棋盘、seed、timeout factor            | Namespace              |
| 2    | `EnvConfig`                           | 上述参数        | 校验                                            | `EnvConfig`            |
| 3    | `SnakeEnv(config)`                    | 配置            | 建环境（种子在每局 reset 时给）                 | 环境                   |
| 4    | `random.Random(seed)`                 | seed            | 独立的动作随机流                                | `action_rng`           |
| 5    | 主循环                                | env、action_rng | `reset(seed+episode)` → `randrange(3)` → `step` | score / steps / ending |
| 6    | 统计与打印                            | 三个列表        | mean / median / max / min / std                 | 终端输出               |

关键点：

- **完全不 import torch**，只依赖 `config.py` + `env/snake_env.py`；所以它既是
  “环境冒烟测试”，也是 DQN 的成绩下界。
- `--render` 时才 lazy import `renderer.py`。
- 不写任何文件，所有结果都在终端。

---

### 12.7 人类试玩：`scripts/play_human.py`

```bash
uv run python scripts/play_human.py
```

| 顺序 | 文件 / 函数                               | 接收               | 负责                                      | 交出                 |
| ---- | ----------------------------------------- | ------------------ | ----------------------------------------- | -------------------- |
| 1    | `parse_args`                              | CLI                | 宽高、格子大小、FPS、seed                 | Namespace            |
| 2    | `EnvConfig` + `SnakeEnv(config, seed)`    | 配置               | 建环境与初始局面                          | 环境                 |
| 3    | `PygameRenderer(env, cell_size)`          | env                | 建窗口、计算棋盘尺寸                      | 渲染器               |
| 4    | pygame 事件循环                           | 键盘/关窗事件      | 把按键翻译成目标绝对方向                  | `desired: Direction` |
| 5    | `relative_action(env.direction, desired)` | 当前朝向、目标朝向 | 绝对方向 → 相对动作；180° 掉头返回 `None` | `Action` 或 `None`   |
| 6    | `env.step(action)`                        | `Action`           | 推进一帧游戏                              | `StepOutcome`        |
| 7    | `renderer.draw(state, status)` / `tick`   | 状态、状态栏文字   | 绘制并限帧                                | 屏幕画面             |
| 8    | `renderer.close()`                        | —                  | `finally` 里释放 pygame                   | —                    |

关键点：

- 方向键给的是**绝对方向**，而环境只接受**相对动作**；`relative_action()` 是两者
  之间唯一的翻译层，也是 `snake_env.py` 里少数给外部用的辅助函数。
- 这条路径没有任何学习、没有 torch；它验证的是“人为操作下环境和渲染是否正常”。
- 死了以后画面停住，按 `R` 重开、`Esc` 退出。

---

### 12.8 命令总览：谁读什么、写什么

| 命令     | 入口                       | 主要参与者                                                     | 读                             | 写                                                                                         | 用 torch |
| -------- | -------------------------- | -------------------------------------------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------ | -------- |
| 训练     | `scripts/train_dqn.py`     | `training/train_dqn` → `agents` / `env` / `models` / `logging` | 无（从零开始）                 | `config.json`、`train.csv`、`eval.csv`、`checkpoint.pt`、`final_eval.json`、`summary.json` | 是       |
| 评估     | `scripts/evaluate.py`      | `agents` / `env` / `training/evaluate` / `logging`             | `config.json`、`checkpoint.pt` | `eval.json`                                                                                | 是       |
| 画曲线   | `scripts/plot_training.py` | matplotlib                                                     | `train.csv`、`eval.csv`        | `curve.png`                                                                                | 否       |
| 测试     | `pytest`                   | `tests/*` + 被导入的包模块                                     | 无                             | `.pytest_cache/`（已忽略）、临时目录                                                       | 是       |
| 随机基线 | `scripts/random_agent.py`  | `env`、`config`                                                | 无                             | 无                                                                                         | 否       |
| 人类试玩 | `scripts/play_human.py`    | `env`、`renderer`、`config`                                    | 无                             | 无                                                                                         | 否       |

最后给一张“要改东西先找谁”的对照表：

| 想改什么             | 先改哪里                        | 跑哪个测试 / 命令                   |
| -------------------- | ------------------------------- | ----------------------------------- |
| 游戏规则、奖励、超时 | `env/snake_env.py`、`config.py` | `pytest tests/test_snake_env.py`    |
| 观察特征             | `env/observations.py`           | `pytest tests/test_observations.py` |
| 网络结构             | `models/qnet.py`、`DQNConfig`   | `pytest tests/test_dqn.py`          |
| 动作选择、TD、更新   | `agents/dqn.py`                 | `pytest tests/test_dqn.py`          |
| 训练调度、日志、存档 | `training/train_dqn.py`         | 5 局 smoke                          |
| 评估指标             | `training/evaluate.py`          | `scripts/evaluate.py`               |
| 图表                 | `scripts/plot_training.py`      | 对已有的 `runs/` 重画               |

> Stage 2 及之后的阶段文档，会按同样的模板补一节“运行时流程”。

---

## 13. 自测题

<details>
<summary>1. 为什么用 gather 只取选中动作的 Q，而不是对三个输出都做 MSE？</summary>

一次 transition 只告诉我们“在 s 做 a 得到 r 和 s'”，所以只有 Q(s,a) 有新目标。
其他动作没有这次的数据。参考项目用 `pred.clone()` 再把选中项覆盖，效果等价；
gather 更直接，也避免对无关输出产生零梯度项。
</details>

<details>
<summary>2. target 里的 `(~done).float()` 在做什么？</summary>

它是一个 0/1 mask。done=True 时乘 0，target 退化为 r；done=False 时保留
`r + γ max Q(s')`。Stage 1 的 done 是 `terminated | truncated`；Stage 2 会改成
只用 terminated。
</details>

<details>
<summary>3. 为什么 target 计算要放在 `torch.no_grad()` 里？</summary>

target 是回归标签，不是要被优化的输出。如果 target 也带梯度，反向传播会同时改变
“预测”和“目标”，让训练目标跟着网络一起动，增加不稳定性。标准 DQN 的 target 是
detach 的。
</details>

<details>
<summary>4. 为什么没有目标网络会导致“追自己尾巴”？</summary>

`target = r + γ max Q_online(s')` 里的 Q 和正在更新的 Q 是同一套参数。每次梯度更新
都会改变 target，网络在追一个自己不断移动的目标。目标网络用一套延迟更新的参数
θ⁻ 计算 target，让目标在一段时间内保持静止。
</details>

<details>
<summary>5. 为什么 greedy eval 全是 timeout？</summary>

可能不是单一原因。常见解释：

- Q 值估计不稳，greedy 选的动作只是“暂时看起来不坏”，并不通向食物；
- 11 维观察没有距离，策略缺少“接近食物”的信息；
- 超时和死亡都给 -10，绕圈的安全收益可能不低于冒险吃食物；
- 训练 score 有一部分来自 epsilon 探索，greedy 策略本身还没学好。
  Stage 2 要一次只改一个变量来区分这些解释。

</details>

<details>
<summary>6. mean100 是什么？它和 greedy eval 有什么区别？</summary>

mean100 是最近 100 个**训练** episode 的 score 均值，策略带 epsilon 探索。
greedy eval 是固定策略、epsilon=0、固定种子的评估。前者看训练趋势，后者看真实策略；
两者不能混为一谈。
</details>

<details>
<summary>7. 为什么 replay 里同时存 terminated 和 truncated？</summary>

为了 Stage 2 可以在不重新采集数据的情况下切换 bootstrap 语义。
Stage 1 用 `terminated | truncated` 复刻参考项目；Stage 2 用 `terminated` 修正超时。
如果只存一个 done，就没法区分这两种情况。
</details>

<details>
<summary>8. Stage 1 的 11 维观察是 Markov 状态吗？</summary>

不是。它没有距离、身体形状和更远的障碍，是部分观察。基于它的策略最多只能
做到“在这个特征下最优”，不是原 MDP 的最优。Stage 3 的观察工程会处理这一点。
</details>

---

## 14. Stage 2 要改什么

按“先正确、再稳定、再提效”的顺序：

| 优先级 | 改动                       | 代码位置           | 预期                            |
| ------ | -------------------------- | ------------------ | ------------------------------- |
| P0     | `bootstrap_truncated=True` | `DQNConfig`        | 超时不再被当成死亡              |
| P0     | 目标网络                   | `DQNAgent`         | target 更稳，减少追尾巴         |
| P1     | Double DQN                 | `compute_targets`  | 降低 max 的高估                 |
| P1     | Huber loss                 | `train_step`       | 对大 TD error 更稳              |
| P1     | 梯度裁剪                   | `train_step`       | 防止突变                        |
| P1     | epsilon 下限/更慢衰减      | `DQNAgent.epsilon` | 后期保留探索                    |
| P2     | 标准 replay minibatch 更新 | `run_training`     | 替代 short memory，比较样本效率 |
| P2     | 多种子 + 更长训练          | CLI                | 区分运气和真实改进              |
| P3     | 观察/奖励工程              | Stage 3            | 提升上限                        |

**Stage 2 的纪律**：一次只开一个开关，跑同一组评估种子，记录消融表。
不要同时加目标网络和 Double DQN，否则不知道是谁的功劳。

---

## 15. 命令速查

先 `cd snake_rl`；`uv run` 会自动使用项目自己的 `.venv`。
WSL 下建议限制线程数（见第 12.2 节和项目 README）。

```bash
# 训练（默认 500 局，20x20，CPU）
OMP_NUM_THREADS=4 uv run python scripts/train_dqn.py

# 指定 run 目录/种子
OMP_NUM_THREADS=4 uv run python scripts/train_dqn.py \
    --seed 1 --output-dir runs/stage1_seed1

# 快速 smoke（10 局）
OMP_NUM_THREADS=4 uv run python scripts/train_dqn.py \
    --episodes 10 --eval-every 5 --eval-episodes 5 \
    --final-eval-episodes 5 --output-dir runs/stage1_smoke

# 评估
uv run python scripts/evaluate.py --run-dir runs/stage1_seed0 --episodes 100

# 画图
uv run python scripts/plot_training.py --run-dir runs/stage1_seed0

# 测试
uv run pytest
```

下一阶段：[05-stage2-dqn-fixes.md](05-stage2-dqn-fixes.md)（待写）。
