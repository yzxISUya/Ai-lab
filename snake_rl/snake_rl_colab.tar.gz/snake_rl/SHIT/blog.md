---
title: 贪吃蛇（RL）
subtitle:
date: 2026-10-26T08:44:56+08:00
slug: 56373d9
draft: false
author:
  name: yzxISUya
  link:
  email:
  avatar:
description:
keywords:
comment: false
weight: 0
tags:
  - draft
categories:
  - draft
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRelated: false
hiddenFromFeed: false
summary:
featuredImagePreview:
featuredImage:
password:
message:
repost:
  enable: false
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

为什么选贪吃蛇呢，因为我觉得需要先来个相对简单的 RL 情景来感受一下

万！丈！高！楼！平！地！起！

于是想到了那些上个世纪的经典街机游戏，贪吃蛇、俄罗斯方块、推箱子...

> 最后选了贪吃蛇，因为很怀念初高中的时候，寝室里有台老年机，里面有贪吃蛇，整个寝室乃至隔壁寝室的人都轮着玩，还比谁分高，好怀念啊，这么个弱智游戏，当时有几个人一起也觉得无敌好玩，可惜回不来了

然后我发现贪吃蛇这个情景太完美了，简直是为了教我 RL 而生，MDP 建模无敌简单且贴切，而且动作离散且小、episode 短、奖励直观、状态空间足够大所以用神经网络是有意义的（不是为了 rl 而 rl），不愧是好游戏

而且贪吃的蛇很可爱捏

<figure class="blog-image">
  <div class="image-wrapper">
    <img id="myImage" src="xxf.webp" alt="贪吃蛇">
  </div>

  <figcaption>
    贪吃蛇
  </figcaption>
</figure>

## 实验环境 && 纯逻辑环境

没用 GPU，因为这个实验比较简单，CPU 应该足够

```powershell
uv pip install --python .\.venv\Scripts\python.exe torch --index-url https://download.pytorch.org/whl/cpu
uv pip install --python .\.venv\Scripts\python.exe matplotlib tqdm
```

包括：纯逻辑环境、只在试玩/演示时用的渲染器、一些测试案例

不是重点，直接拿 AI 一把写，略

## DQN 基线

> 在此之前原本搞了个随机基线，但显然没什么意义，随机显然均值上连 1 分都拿不到，没什么比较意义，但是又不知道有什么别的极其简单且有效的策略了，所以直接用一个最简单的 DQN 建模当基线，其实这样反而很好，一个足够高但显然不完美的策略，非常适合当基线

### 配置

- 只有 11 维，没错，从比较简单的角度来看只有 11 维，而且实测证明有效，甚至说效果出奇的好：

> **3 个危险位（只一格内，相当于蛇对墙的视力是 1） + 4 个当前朝向 one-hot（不用1234，防止赋予虚假的大小顺序和距离关系） + 4 个食物相对方位（对食物视力正无穷）**，还挺符合第一直觉的

- MLP 则是 11—256—3，其实感觉 256 都多了
```python
class QNet(nn.Module):
    def __init__(self, input_size=11, hidden_size=256, output_size=3):
        self.linear1 = nn.Linear(input_size, hidden_size)
        self.linear2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        return self.linear2(F.relu(self.linear1(x)))
```
- 没有目标网络，目标纯用在线网络算
- TD(0)、MSE loss:
```python
pred = self.model(obs)                                  # (B, 3)
pred_q = pred.gather(1, actions.unsqueeze(1)).squeeze(1)  # (B,)
target = self.compute_targets(batch)                    # (B,)
loss = self.criterion(pred_q, target)                   # MSE
```
- ε-greedy（就是概率贪心，ε 的概率随机探索，1-ε 的概率朝 Q 最大贪心）
- short memory transition，一步得到一条经验，一步一更新
- Long memory，有经验回放，容量 100k，每局结束之后从经验池抽取一个 batch 学习更新
```python
# 每一条经验；
class Transition(NamedTuple):
    obs: np.ndarray
    action: int
    reward: float
    next_obs: np.ndarray
    terminated: bool
    truncated: bool
```
- 默认把 truncation 当成 termination，比如超时超步数上限、意外中断都算死了

### 小巧思优化

epsilon 不是固定的！随轮数变化（叫 epsilon 调度），这个挺天才的：

```python
progress = min(1.0, n_games / epsilon_decay_games)
epsilon = epsilon_start + progress * (epsilon_end - epsilon_start)
```

默认 0.4 -> 0.0，持续 80 局

### 训练循环

```python
for episode in range(1, episodes + 1):
    env.reset(seed=seed + episode)
    obs = observe(env)

    while not env.done:
        action = agent.get_action(obs)
        outcome = env.step(action)
        next_obs = observe(env)

        transition = Transition(obs, action, outcome.reward, next_obs,
                                outcome.terminated, outcome.truncated)

        if short_memory:
            agent.train_short_memory(transition)   # 每步单样本
        agent.remember(transition)

        obs = next_obs

    agent.end_episode()          # n_games += 1，epsilon 衰减
    agent.train_long_memory()    # 每局 replay batch
```

### 结果

还是有点出乎意料的...失败，它似乎什么都没学会：

20×20，CPU：

| episode | train score | mean100 | epsilon | greedy eval mean | eval 结束方式 |
| ------: | ----------: | ------: | ------: | ---------------: | ------------- |
|      10 |           1 |    0.20 |   0.355 |                — | —             |
|      25 |           1 |    0.52 |   0.280 |             0.00 | timeout 20    |
|      50 |           1 |    0.86 |   0.155 |             0.55 | timeout 20    |

最后 greedy 评估：

- mean 0.55，median 0.0，max 3，std 0.94
- 平均步数 370.8
- 20 局全部 timeout
- 训练 4744 步，29.2 秒（约 163 步/秒）

但是注意到这里是超时！所以没学会的原因可能不是策略太垃圾、学错了，而是什么都没学，这确实符合我之前学 rl 时的质疑

结合 AI 分析罗列了一下原因：

1. 没有目标网络，Q 值估计不稳定，greedy 动作不等于“会找食物”的动作；
2. 11 维观察没有距离，策略很难稳定地朝食物走；
3. epsilon 在 50 局时还有 0.155，训练 score 有一部分来自探索；
4. 超时和死亡都给 -10，agent 可能更倾向于“安全地绕圈”而不是冒险接近食物；
5. short memory 每步更新 + 每局 batch 更新，二者的相对权重没有调过。

> AI:你的完整训练表明，至少“学不会”这个判断是错的；真正的问题是**训练规模和评估局数都太小**

于是直接加大到 500 轮：

500 局 baseline：最终结果

训练：**189,708 步，922.3 秒，约 205.7 步/秒**（约 15.4 分钟，CPU）

最终 greedy 评估（100 局，seed=20_000 起）：

| 指标                        |             值 |
| --------------------------- | -------------: |
| mean                        |      **27.14!牛逼！** |
| median                      |           26.0 |
| max                         |             52 |
| min                         |              1 |
| std                         |          10.13 |
| mean steps                  |         405.44 |
| score/step                  |         0.0669 |
| wall / self / timeout / win | 5 / 95 / 0 / 0 |

训练过程中每 50 局的 20 局 greedy eval：

| episode   |   50 |   100 |   150 |   200 |   250 |   300 |   350 |   400 |   450 |   500 |
| --------- | ---: | ----: | ----: | ----: | ----: | ----: | ----: | ----: | ----: | ----: |
| eval mean | 0.55 | 25.20 | 26.50 | 28.85 | 30.30 | 23.85 | 25.90 | 32.60 | 25.70 | 29.60 |

<figure class="blog-image">
  <div class="image-wrapper">
    <img id="myImage" src="stage1_curve.png" alt="训练曲线">
  </div>

  <figcaption>
    训练曲线
  </figcaption>
</figure>

- 50–100 局之间出现暴增！但是之后莫名其妙没收益了，几乎全是无效
- 主要是吃自己死的，这个早有预料，毕竟吃自己这个信息，我刻意没有将其过多纳入经验维度中

**看起来很纯也很蠢，很多显然粗糙、不合理的设计，但是效果出奇的有意思，不赖**

但是我还是觉得奇怪：我的隐藏维度是 256 维呀，虽然网络只有两层，但是从图片来看，只有一次跃升，这是为什么？蛇只学到了一种规律？还是恰巧在这一期间学会了多种规律？我当然知道现在的建模很烂，但是也不应该啊，难道 500 轮还不够？

还有一种可能：**对危险的视力只有 1 导致极其容易吃自己而死，这使智能体的上限被卡死（而且这个上限很低），也就是 100 轮训练时就已经到达了上限**

换而言之，**该学的都学了，死了不是失误，而是被迫死亡**，三个方向都是墙/身体，必须死

## 增加输入维度

### 为什么应该优先这么做

原本我的 ai agent 给我的下一步建议：

> 下一步: 目标网络 / Double / Huber / 正确 truncation，逐项消融

但我认为这不好

既然上限可能是被危险感知视力（1）卡死，那么优化别的东西暂时可能没用（体现不出来），所以直接优化建模：**增加状态信息以提高视力，即增加输入维度**

为了保险起见，还是让 ai 评估了一下：应该先增加稳定性还是先增加信息量

可能是我问的太泛了，而且没约束 ai 的思考方式，它居然直接拿着我的电脑跑起来了？！真蠢

但是还是让它跑完了，结论是：

> **优先增加信息量，即增加输入维度**

又是一次对ai的依赖，对自己的不信任，又消耗了三毛钱 tokens，悲剧

11 维太少了，**我突然发现，这不仅是 11 维，这他妈是 11 个 bool 值啊！艹，这不蠢傻逼吗，11 个 bool，顶了天 2048 个状态，这本质是个表啊，网络建模压根没有展现出优势**

极其失败的基线，没关系，好事，接下来不可能负优化

### 加的维度给到谁，优先加到什么信息上

这个问题我感觉有点难，一个好的新维度自然要尽可能高的信息密度，不能与前 11 维重叠，也不能是无效/无意义的信息，还要尽可能地好算

这我真得问 AI:

```
如果只能选三个方向

按性价比，我会选：

1. 每个动作执行后的 BFS 食物距离 + tail-safe 位（3+3 维）
   这是从 ~30 到 ~58 的关键。
2. 当前可达空格数 / 蛇长 + tail 可达性 + tail BFS 距离（3 维）
   这是从“会吃”到“不会把自己围死”的关键。
3. egocentric 坐标系 + 4/8 方向身体射线（12–24 维）
   这是便宜、通用、旋转不变的身体几何表示，替代昂贵的全网格 CNN。

这三组加起来大约 20–30 维，预期比“把 11 维随便加到 50 维”有效得多。
```

**逆天啊！**

**还给你 BFS 上了？？？BFS 距离？那这不是开挂吗？理论上纯算法不依赖 rl 也能造出能赢下游戏的蛇啊，我的目的是为了通过 rl，让蛇自己学习，怎么能直接告诉他 BFS 距离这些由算法算出的东西呢？退一万步，工程复杂 RL 确实可以和算法结合，用算法二级结论喂给 agent 当信息，但我这是学习 RL 啊，我这是实验啊，这么简单个情景，你还开挂，无敌了**

woc，欸，不对，我发现照这么说我前面 11 维都是开挂的，都不是纯 RL，都是人为封装地信息

**但是 BFS 还是过分了，工程上复杂问题如 data2 ai 这种无法找到固定算法的问题肯定可以用 BFS，但是贪吃蛇还用纯开挂**，还是判处 AI 有罪

> 重申一遍：我是在学习，不是开发

那还说啥了，整个地图给你了，全喂进去，**ALL IN**！

### 为什么不应该优先这么做

事情发生了一些微妙的变化，因为我选择了 ALL IN，出于纯粹的学习与想要见证 RL

于是：**观察瓶颈被移除了**

取而代之的是： **高维输入 比 11 维 MLP 难训得多，稳定性问题会立刻变得重要**

不过 400 维，每一维就 5 个有限状态（蛇，空，墙，果），再来个额外的头信息（位置、方向），这样实际上就只有 2000 个 bool 参数左右

有点讽刺了，兜兜转转回到了原点

不过此时不必再使用 MLP 了，直接 CNN，因为有明显的空间关系

> **怎么感觉越学越偏了🤔**

## 目标网络 和 Double DQN

说实话我学的时候就觉得这东西抽象，我能理解它稳定，但是凭什么会有收益？很神奇，把旧的目标冻结真的会有收益吗？

实践了一下，结果：负收益，平均所有数据都变差个 3%

果然难绷，可能这东西就是没收益吧，纯粹为了好算/稳定，也有可能当前的 MLP 太简单，限制其发挥了

后期再看吧，看这东西要不要开

至于 Double DQN，差不多吧，一样抽象的东西，我难以理解其优越性

## 全棋盘 CNN 第一轮

11 维手工特征改为 (5,20,20) 棋盘；模型从 MLP 改为 BoardQNet

主要配置：

- 依旧 500 局；batch 128；replay 20k；每 2 个环境步 replay 更新
- epsilon 0.4 → 0.02，150 局衰减
- 目标网络 + Double DQN；MSE
- 每 50 局 20 局 eval；最终 100 局；device=auto→CUDA

只花了 3 分多钟

结果：

- eval mean：**0.17**
- median / max / std：0 / 2 / 0.40
- 结束方式：wall 56 / timeout 44 / self 0

基本就是随机游走，什么也没学会，根据之前的经验，我下一步选择无脑堆训练量

## 全棋盘 CNN 第二轮

直接变 5000 局，batch 256；replay 50k，以防万一设置了一个 45min 的超时锁

居然超时了，实际训练轮数：2486，还是太保守了，开英伟达浮窗看了一下，gpu 的使用率一直在 60% 左右

结果：

- eval mean：**0**
- median / max / std：0 / 0 / 0
- 结束方式：wall 0 / timeout 100 / self 0

有意思，居然退化了，大概是退化成了转圈，一直转圈直至超时

宁愿超时死亡也不愿意尝试，我寻思现在超时不也是当作死亡吗？这惩罚还不够？宁愿把确定的惩罚推到最后一步也不愿意最后一舞，还挺像

> 安全活到超时比冒险找食物更稳，确实像

## 全棋盘 CNN 第三轮